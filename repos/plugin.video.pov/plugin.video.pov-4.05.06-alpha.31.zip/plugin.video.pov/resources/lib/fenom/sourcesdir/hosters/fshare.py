import re
from datetime import datetime
from apis.fshare_api import FshareAPI
from fenom import source_utils
from modules.kodi_utils import logger
from modules.utils import no_accent_vietnamese

class source:
    priority = 1
    pack_capable = False
    hasMovies = True
    hasEpisodes = True

    def __init__(self):
        self.language = ['en', 'vi']
        self.fshare_api = FshareAPI()

    def sources(self, data, hostDict):
        sources = []
        if not data:
            return sources
        append = sources.append
        try:
            title = data['tvshowtitle'] if 'tvshowtitle' in data else data['title']
            episode_title = data['title'] if 'tvshowtitle' in data else None
            aliases = data.get('aliases') or []
            aliases_list = [a['title'] for a in aliases]
            alias = aliases_list[0] if aliases_list else None
            year = data.get('year')
            season = data.get('season')
            episode = data.get('episode')
            season_data = data.get('season_data', [])
            hdlr = 'S%02dE%02d' % (int(season), int(episode)) if 'tvshowtitle' in data else year
            years = None
            if hdlr == year:
                years = [year]
                years.append(str(int(year) - 1))
            search_extra = dict(
                year=year,
                season=season,
                episode=episode,
                season_data=season_data,
                alias=alias,
            )
            if aliases:
                aliases.insert(0, dict(title=no_accent_vietnamese(alias)))
                if season:
                    try:
                        season_obj = [s for s in season_data if s['season_number'] == int(season)]
                        if season_obj:
                            season_date = datetime.strptime(season_obj[0]['air_date'], '%Y-%m-%d')
                            suffix_list = [season_date.year]
                            if int(season) > 1:
                                suffix_list.insert(0, season)
                                suffix_list.append(f'{season} {season_date.year}')
                            for s in suffix_list:
                                aliases.append(dict(title=f"{title} {s}"))
                                aliases.append(dict(title=f"{alias} {s}"))
                                aliases.append(dict(title=f"{no_accent_vietnamese(alias)} {s}"))
                    except: pass
            results = self.fshare_api.search(title, **search_extra)
            logger('FSHARE', f'[Scrape] {title}: {len(results)}')

            for item in results:
                url = item.get('link')
                raw_name = no_accent_vietnamese(item['title'].lower())
                name_parts = raw_name.split('-', 1)
                if len(name_parts) == 2:
                    for i, n in enumerate(name_parts):
                        if title.lower() in n:
                            pos = i + 1 if i == 0 else i - 1
                            raw_name = raw_name.replace(name_parts[pos], '').strip()
                            break
                for alias in aliases_list:
                    _s_lower = alias.lower()
                    raw_name = raw_name.replace(_s_lower, title)
                    raw_name = raw_name.replace(no_accent_vietnamese(_s_lower), title)
                if season and int(season) == 1:
                    start_ep_regexp = r'^e[\s|p]?(\d{1,3})\.'
                    raw_name = re.sub(r'\.e[\s|p]?(\d{1,3})\.', r'.S%02dE\1.' % 1, raw_name)
                    if re.search(start_ep_regexp, raw_name) and \
                        (source_utils.clean_name(title).lower() in raw_name or title.lower() in raw_name):
                        raw_name = re.sub(start_ep_regexp, r'%s.S%02dE\1.' % (title, 1), raw_name)
                name = source_utils.clean_name(raw_name)
                name = re.sub(r'^(vietsub|tm).', '', name)
                if item.get('check') is None and not source_utils.check_title(title, aliases, name, hdlr, year, years=years):
                    # logger('FSHARE', f'[{title}] {name} {url} not passed')
                    continue
                name_info = source_utils.info_from_name(name, title, year, hdlr, episode_title)
                quality, info = source_utils.get_release_quality(name_info, url)
                try:
                    dsize, isize = source_utils.convert_size(float(item["size"]), to='GB')
                    info.insert(0, isize)
                except:
                    dsize = 0
                info = ' | '.join(info)

                is_exists = item.get('check') is None and any(s for s in sources if s['quality'] == quality and s['size'] == dsize)
                if not is_exists:
                    append({'provider': 'fshare', 'source': item.get('provider', 'hoster'), 'name': name, 'name_info': name_info,
                            'quality': quality, 'language': 'vi', 'url': url, 'info': info,
                            'direct': True, 'debridonly': False, 'size': dsize})
            logger('FSHARE', f'[Scrape filter] {title}: {len(sources)} results')
        except Exception as e:
            logger('FSHARE', e)
            source_utils.scraper_error('FSHARE')
        return sources
