import os
import sys
import json
import xbmc
import re
from threading import Thread
from apis.yifysubtitles_api import YifySubtitlesAPI
from apis.opensubtitles_api import OpenSubtitlesAPI
from apis.subdl_api import SubdlAPI
from apis.subdlorg_api import SubdlOrgAPI
from apis.subsource_api import SubsourceAPI
from caches.main_cache import main_cache
from datetime import timedelta
from modules import kodi_utils
from modules.utils import slugify

__scriptid__ = 'plugin.video.pov'

def get_params(string=""):
    param = []
    if string == "":
        paramstring = sys.argv[2]
    else:
        paramstring = string
    if len(paramstring) >= 2:
        params = paramstring
        cleanedparams = params.replace('?', '')
        if (params[len(params) - 1] == '/'):
            params = params[0:len(params) - 2]
        pairsofparams = cleanedparams.split('&')
        param = {}
        for i in range(len(pairsofparams)):
            splitparams = {}
            splitparams = pairsofparams[i].split('=')
            if (len(splitparams)) == 2:
                param[splitparams[0]] = splitparams[1]

    return param

class SubtitleService:

    def __init__(self):
        self.cache_key = 'subtitle_service_result_'
        self.yify = YifySubtitlesAPI()
        self.osdb = OpenSubtitlesAPI()
        self.subdl = SubdlAPI()
        self.subdlorg = SubdlOrgAPI()
        self.subsource = SubsourceAPI()
        self.subtitles = []

    def search(self, handle, **params):
        meta = json.loads(kodi_utils.get_property('pov_playback_meta'))
        preferred_language = params.get('preferredlanguage')
        languages = params.get('languages').split(',')
        language = languages[0]
        if preferred_language and preferred_language in languages:
            language = preferred_language
        lang_code = kodi_utils.convert_language(language)
        imdb_id = meta.get("imdb_id")
        tmdb_id = meta.get("tmdb_id")
        year = meta.get("year")
        title = meta.get("original_title")
        en_title = meta.get("english_title")
        season = meta.get("season")
        episode = meta.get("episode")
        video_title =  xbmc.getInfoLabel('VideoPlayer.OriginalTitle')
        if video_title == '':
            video_title = xbmc.getInfoLabel('VideoPlayer.Title')
        search_title = en_title or title

        cache_name = f'{self.cache_key}_{imdb_id or tmdb_id or slugify(en_title)}_{lang_code}'
        if season and episode:
            cache_name += f'_s{season}e{episode}'
        cache = main_cache.get(cache_name)
        if not cache:
            threads = []
            if not season and not episode:
                threads.append(Thread(target=self._search_yify, args=(imdb_id, search_title, lang_code)))
            threads.append(Thread(target=self._search_osdb, args=(imdb_id, search_title, lang_code, season, episode, tmdb_id, year)))
            threads.append(Thread(target=self._search_subdlorg, args=(imdb_id, search_title, lang_code, season, episode, tmdb_id, year)))
            threads.append(Thread(target=self._search_subsource, args=(imdb_id, search_title, lang_code, season, episode, tmdb_id, year)))
            threads.append(Thread(target=self._search_subdl, args=(imdb_id, search_title, lang_code, season, episode, tmdb_id, year)))

            for t in threads:
                t.start()

            for t in threads:
                t.join()

            main_cache.set(cache_name, self.subtitles, expiration=timedelta(hours=24))
        else:
            self.subtitles = cache

        self.subtitles = self._prepare_results(video_title, self.subtitles)

        for sub in self.subtitles:
            (item_name, item_ext) = os.path.splitext(sub.get('MovieReleaseName'))
            item_name = item_name.replace('.', ' ')
            item_ext = item_ext.upper()[1:]
            item_service = sub['SubProvider']
            listitem = kodi_utils.make_listitem()
            listitem.setLabel(language)
            listitem.setLabel2('[[B]%s[/B]] %s' % (item_service, item_name))
            kodi_utils.add_item(
                handle=handle,
                listitem=listitem,
                isFolder=False,
                url='plugin://%s/?action=download&provider=%s&url=%s&filename=%s&name=%s&season=%s&episode=%s' % (
                  __scriptid__,
                  item_service,
                  sub['ZipDownloadLink'].rstrip(),
                  sub['SubFileName'],
                  sub['MovieReleaseName'],
                  season,
                  episode,
                )
            )

    def download(self, handle, **params):
        url = params.get('url')
        name = params.get('name').replace(' ', '.')
        filename = params.get('filename')
        season = params.get('season')
        episode = params.get('episode')
        provider = params.get('provider').lower()
        subtitle_path = kodi_utils.translate_path('special://temp/')
        sub_filename = 'POVSubs_%s_%s_%s' % (name, season, episode) if season else 'POVSubs_%s' % name
        final_filename = sub_filename + '.srt'
        temp_zip = os.path.join(subtitle_path, 'temp.zip')
        temp_path = os.path.join(subtitle_path, filename)
        final_path = os.path.join(subtitle_path, final_filename)

        downloaded_path = None
        if provider == 'yify':
            downloaded_path = self.yify.download(url, subtitle_path, temp_zip, temp_path, final_path)
        elif provider == 'subsource':
            downloaded_path = self.subsource.download(url, subtitle_path, temp_zip, temp_path, final_path)
        elif provider == 'osdb':
            downloaded_path = self.osdb.download(url, subtitle_path, temp_zip, temp_path, final_path)
        elif provider == 'subdl':
            downloaded_path = self.subdl.download(url, subtitle_path, temp_zip, temp_path, final_path)
        else:
            downloaded_path = self.subdlorg.download(url, subtitle_path, temp_zip, temp_path, final_path)

        if not downloaded_path:
            return

        xbmc.Player().setSubtitles(downloaded_path)
        listitem = kodi_utils.make_listitem()
        listitem.setLabel(downloaded_path)
        kodi_utils.add_item(handle=handle, url=downloaded_path, listitem=listitem, isFolder=False)

    def run(self, handle, **params):
        action = params.get('action')
        if action in ['search', 'manualsearch']:
            self.search(handle, **params)
        elif action == 'download':
            self.download(handle, **params)

        kodi_utils.end_directory(handle)

    def _prepare_provider_result(self, provider, result):
        for r in result:
            r['SubProvider'] = provider
        return result

    def _prepare_results(self, filename, results):
        release_groups = [
            ['bluray', 'blu-ray', 'bd', 'bdrip', 'brrip', 'bdmv', 'bdscr', 'remux', 'bdremux', 'uhdremux', 'uhdbdremux', 'uhdbluray'],
            ['web', 'webdl', 'webrip', 'webr', 'webdlrip', 'webcap'],
            ['dvd', 'dvd5', 'dvd9', 'dvdr', 'dvdrip', 'dvdscr'],
            ['scr', 'screener', 'r5', 'r6']
        ]
        release = []
        for group in release_groups:
            release.extend(group)
        release.extend(['avi', 'mp4', 'mkv', 'ts', 'm2ts', 'mts', 'mpeg', 'mpg', 'mov', 'wmv', 'flv', 'vob'])

        quality_groups = [
            ['4k', '2160p', '2160', '4kuhd', '4kultrahd', 'ultrahd', 'uhd'],
            ['1080p', '1080'],
            ['720p', '720'],
            ['480p'],
            ['360p', '240p', '144p'],
        ]
        quality = []
        for group in quality_groups:
            quality.extend(group)

        service_groups = [
            ['netflix', 'nflx', 'nf'],
            ['amazon', 'amzn', 'primevideo'],
            ['hulu', 'hlu'],
            ['crunchyroll', 'cr'],
            ['disney', 'disneyplus'],
            ['hbo', 'hbonow', 'hbogo', 'hbomax', 'hmax'],
            ['bbc'],
            ['sky', 'skyq'],
            ['syfy'],
            ['atvp', 'atvplus'],
            ['pcok', 'peacock'],
        ]
        service = []
        for group in service_groups:
            service.extend(group)

        codec_groups = [
            ['x264', 'h264', '264', 'avc'],
            ['x265', 'h265', '265', 'hevc'],
            ['av1', 'vp9', 'vp8', 'divx', 'xvid'],
        ]
        codec = []
        for group in codec_groups:
            codec.extend(group)

        audio_groups = [
            ['dts', 'dtshd', 'atmos', 'truehd'],
            ['aac', 'ac'],
            ['dd', 'ddp', 'ddp5', 'dd5', 'dd2', 'dd1', 'dd7', 'ddp7'],
        ]
        audio = []
        for group in audio_groups:
            audio.extend(group)

        color_groups = [
            ['hdr', '10bit', '12bit', 'hdr10', 'hdr10plus', 'dolbyvision', 'dolby', 'vision'],
            ['sdr', '8bit'],
        ]
        color = []
        for group in color_groups:
            color.extend(group)

        extra = ['extended', 'cut', 'remastered', 'proper']

        filename = filename.lower()
        regexsplitwords = r'[\s\.\:\;\(\)\[\]\{\}\\\/\&\€\'\`\#\@\=\$\?\!\%\+\-\_\*\^]'
        nameparts = re.split(regexsplitwords, filename)

        release_list = [i for i in nameparts if i in release]
        quality_list = [i for i in nameparts if i in quality]
        service_list = [i for i in nameparts if i in service]
        codec_list = [i for i in nameparts if i in codec]
        audio_list = [i for i in nameparts if i in audio]
        color_list = [i for i in nameparts if i in color]
        extra_list = [i for i in nameparts if i in extra]

        for item in release_list:
            for group in release_groups:
                if item in group:
                    release_list = group
                    break

        for item in quality_list:
            for group in quality_groups:
                if item in group:
                    quality_list = group
                    break

        for item in service_list:
            for group in service_groups:
                if item in group:
                    service_list = group
                    break

        for item in codec_list:
            for group in codec_groups:
                if item in group:
                    codec_list = group
                    break

        for item in audio_list:
            for group in audio_groups:
                if item in group:
                    audio_list = group
                    break

        for item in color_list:
            for group in color_groups:
                if item in group:
                    color_list = group
                    break

        def sorter(x):
            name = x['MovieReleaseName'].lower()
            nameparts = re.split(regexsplitwords, name)

            return (
                -sum(i in nameparts for i in quality_list) * 10,
                -sum(i in nameparts for i in release_list) * 10,
                -sum(i in nameparts for i in codec_list) * 10,
                -sum(i in nameparts for i in service_list) * 10,
                -sum(i in nameparts for i in audio_list),
                -sum(i in nameparts for i in color_list),
                -sum(i in nameparts for i in extra_list),
                x['SubProvider'],
            )

        results = sorted(results, key=sorter)

        return results

    def _search_yify(self, imdb_id, title, language):
        result = self.yify.search(title, imdb_id, language)
        if result:
            self.subtitles.extend(self._prepare_provider_result('YIFY', result))

    def _search_subsource(self, imdb_id, title, language, season, episode, tmdb_id, year):
        result = self.subsource.search(title, imdb_id, language, season, episode, **dict(tmdb_id=tmdb_id, year=year))
        if result:
            self.subtitles.extend(self._prepare_provider_result('Subsource', result))

    def _search_osdb(self, imdb_id, title, language, season, episode, tmdb_id, year):
        result = self.osdb.search(title, imdb_id, language, season, episode, **dict(tmdb_id=tmdb_id, year=year))
        if result:
            self.subtitles.extend(self._prepare_provider_result('OSDB', result))

    def _search_subdlorg(self, imdb_id, title, language, season, episode, tmdb_id, year):
        result = self.subdlorg.search(title, imdb_id, language, season, episode, **dict(tmdb_id=tmdb_id, year=year))
        if result:
            self.subtitles.extend(self._prepare_provider_result('SubdlORG', result))

    def _search_subdl(self, imdb_id, title, language, season, episode, tmdb_id, year):
        result = self.subdl.search(title, imdb_id, language, season, episode, **dict(tmdb_id=tmdb_id, year=year))
        if result:
            self.subtitles.extend(self._prepare_provider_result('Subdl', result))
