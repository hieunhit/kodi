import difflib
import json
import re
from bs4 import BeautifulSoup
from datetime import timedelta
from random import randint
from urllib.parse import urlparse, parse_qs
from threading import Thread
from requests import Session
from caches.main_cache import main_cache
from modules.agent_lists import FIRST_THOUSAND_OR_SO_USER_AGENTS as AGENT_LIST
from modules.kodi_utils import get_setting, set_setting

BASE_URL = 'https://api.fshare.vn/api'
HDVN_URL = 'https://www.hdvietnam.xyz'
HDVN_USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36 Edg/115.0.0.0"
HDVN_COOKIE = "xf_user=1983091%2C8cdb6cf90d618349958e40ea9b57b628dffd971c"
YEAR_REGEX = r"(19|20)\d{2}"
VIDEO_REGEX = r"^.*(mkv|mp4|avi|wmv|flv|mov|mpg|mpeg|3gp|webm|ts|iso)$"
CLEAN_REGEX = r"\((?:[^\)|]*\|)?([^\)|]*)\)"
CLEAN_BRACKET_REGEX = r"\[(?:[^\]|]*\|)?([^\]|]*)\]"

class FshareAPI:

    def __init__(self):
        self.session = Session()
        self.hdvn = HDVNSearch()
        self.app_key = 'dMnqMMZMUnN5YpvKENaEhdQQ5jxDqddt'
        self.username = get_setting('fshare.username')
        self.password = get_setting('fshare.password')
        self.token = get_setting('fshare.token')
        self.sessionid = get_setting('fshare.sessionid')
        self.headers = {
            'cache-control': 'no-cache',
            'User-Agent': 'kodivietmediaf-K58W6U'
        }
        self.login()

    def login(self):
        if self.token and self.sessionid:
            if self.check_login(self.token, self.sessionid):
                return self.token, self.sessionid
        if not self.username or not self.password:
            return False
        req_data = json.dumps({
            'user_email': self.username,
            'password': self.password,
            'app_key': self.app_key,
        })
        resp = self.session.post(BASE_URL + '/user/login', headers=self.headers, data=req_data)
        if resp.status_code == 200:
            resp_data = resp.json() if resp else {}
            self.token = resp_data.get('token')
            self.sessionid = resp_data.get('session_id')
            set_setting('fshare.token', self.token)
            set_setting('fshare.session', self.sessionid)
            return self.token, self.sessionid
        return False

    def logout(self):
        if not self.token or not self.sessionid:
            return False
        req_headers = self.headers
        req_headers.update(Cookie='session_id=' + self.sessionid)
        self.session.get(BASE_URL + '/user/logout', headers=req_headers)
        return True

    def check_login(self, token, session):
        if not token or not session:
            return False
        req_headers = self.headers
        req_headers.update(Cookie='session_id=' + session)
        resp = self.session.get(BASE_URL + '/user/get', headers=req_headers)
        if resp.status_code == 200:
            return True
        return False

    def search(self, title, **kwargs):
        results = []
        if not self.login():
            return results
        threads = []
        threads.append(Thread(target=self._search_hdvn, args=(title, results), kwargs=kwargs))
        threads.append(Thread(target=self._search_phongblack, args=(title, results), kwargs=kwargs))
        threads.append(Thread(target=self._search_thuvienhd, args=(title, results), kwargs=kwargs))
        threads.append(Thread(target=self._search_tvcine, args=(title, results), kwargs=kwargs))

        for t in threads:
            t.start()
        for t in threads:
            t.join()
        results = self._remove_duplicate(results)

        return results

    # def _search_timfshare(self, title, result, **kwargs):
    #     year = kwargs.get('year')
    #     season = kwargs.get('seasion')
    #     episode = kwargs.get('episode', 1)
    #     search_title = title
    #     if year:
    #         search_title += ' ' + str(year)
    #     if season:
    #         search_title += f' S{season.zfill(2)}E{episode.zfill(2)}'
    #     req_headers = {
    #         'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36',
    #         'Authorization': 'Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJuYW1lIjoiZnNoYXJlIiwidXVpZCI6IjcxZjU1NjFkMTUiLCJ0eXBlIjoicGFydG5lciIsImV4cGlyZXMiOjAsImV4cGlyZSI6MH0.WBWRKbFf7nJ7gDn1rOgENh1_doPc07MNsKwiKCJg40U',
    #     }
    #     resp = self.session.post('https://api.timfshare.com/v1/string-query-search', params={
    #         'query': search_title,
    #     }, headers=req_headers)
    #     results = []
    #     if resp.status_code == 200:
    #         resp_data = resp.json() if resp else {}
    #         for item in resp_data.get('data', []):
    #             name = item.get('name')
    #             if difflib.SequenceMatcher(
    #                     None,
    #                     f"{title} S{season.zfill(2)}E{episode.zfill(2)}" if season else title,
    #                     name
    #                 ).ratio() < 0.5:
    #                 continue
    #             if not re.match(VIDEO_REGEX, name):
    #                 continue
    #             results.append({
    #                 'title': name,
    #                 'link': item.get('url'),
    #                 'size': item.get('size'),
    #             })
    #     result.extend(results)
    #     return results

    def _search_phongblack(self, title, result, **kwargs):
        year = kwargs.get('year')
        season = kwargs.get('season')
        episode = kwargs.get('episode', 1)
        search_title = title
        req_headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36 VietMedia/1.0',
            'Referers': 'http://www.google.com',
        }
        resp = self.session.post("https://phongblack.me/search.php?author=phongblack", params=dict(
            search=search_title,
        ), headers=req_headers)
        search_ep = f"S{season.zfill(2)}E{episode.zfill(2)}" if season and episode else None
        results = []
        if resp.status_code == 200:
            resp_data = resp.json() if resp else {}
            data = [item for item in resp_data.get('items', []) if 'fshare.vn' in item.get('path')]
            for item in data:
                name = item.get('label')
                path = item.get('path')
                url = parse_qs(urlparse(path).query).get('url')[0]
                name_strip = re.sub(CLEAN_BRACKET_REGEX, '', name)
                parts = name_strip.split(' - ')
                title_ratio = 0
                for p in parts:
                    if title_ratio >= 0.7:
                        continue
                    title_ratio = difflib.SequenceMatcher(
                        None,
                        title,
                        re.sub(CLEAN_REGEX, '', p.replace(year, '')).strip()
                    ).ratio()
                if title_ratio >= 0.7:
                    if '/folder/' in url:
                        files = self._get_folder_files(url, search_ep)
                        results.extend(files)
                    else:
                        file_info = self._get_file_info(url, search_ep)
                        if file_info and year in file_info.get('title'):
                            results.append(file_info)
        results = self._remove_duplicate(results)
        result.extend(results)
        return results

    def _search_thuvienhd(self, title, result, **kwargs):
        year = kwargs.get('year')
        season = kwargs.get('season')
        episode = kwargs.get('episode', 1)
        req_headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36',
            'Referer': 'http://www.google.com',
        }
        resp = self.session.get('https://thuvienhd.com', params={
            'feed': 'fsharejson',
            'search': title,
        }, headers=req_headers)
        search_ep = f"S{season.zfill(2)}E{episode.zfill(2)}" if season and episode else None
        results = []
        if resp.status_code == 200:
            resp_data = resp.json() if resp else []
            for item in resp_data:
                name = item.get('title')
                title_ratio = difflib.SequenceMatcher(None, title, name.split('&&', 1)[1]).ratio()
                if title_ratio >= 0.7:
                    for link_item in item.get('links', []):
                        url = link_item.get('link')
                        if '/folder/' in url:
                            files = self._get_folder_files(url, search_ep)
                            results.extend(files)
                        else:
                            file_info = self._get_file_info(url, search_ep)
                            if file_info and year in file_info.get('title'):
                                results.append(file_info)
        results = self._remove_duplicate(results)
        result.extend(results)
        return results

    def _search_tvcine(self, title, result, **kwargs):
        base_url = 'https://thuviencine.com'
        year = kwargs.get('year')
        season = kwargs.get('season')
        episode = kwargs.get('episode', 1)
        cache_key = f"tvcine_{title}_{year}"
        if season:
            cache_key += f"_S{season.zfill(2)}E{episode.zfill(2)}"
        results = []
        cache_data = main_cache.get(cache_key)
        if cache_data:
            results = cache_data
        else:
            req_headers = {
                'User-Agent': AGENT_LIST[randint(0, len(AGENT_LIST) - 1)],
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                'Accept-Language': 'en-US,en;q=0.5',
                'Accept-Encoding': 'gzip, deflate',
                'DNT': '1',
                'Connection': 'keep-alive',
                'Upgrade-Insecure-Requests': '1',
                'Cache-Control': 'max-age=0'
            }
            search_ep = f"S{season.zfill(2)}E{episode.zfill(2)}" if season and episode else None
            link = None
            item_id = None
            resp = self.session.get(base_url, params={'s': title}, headers=req_headers)
            if resp.status_code == 200:
                soup = BeautifulSoup(resp.content, 'html.parser')
                div_items = soup.find_all("div", {"id": lambda x: x and x.startswith("post-")})
                for div in div_items:
                    name = div.find('h2', class_='movie-title').text.strip()
                    if title not in name and year not in name:
                        continue
                    link = div.find("a")["href"]
                    item_id = div.get('id').replace('post-', '')
                    if link and item_id:
                        link = f"{base_url}/download?id={item_id}"
                        break
            if link:
                resp = self.session.get(link, headers=req_headers)
                if resp.status_code == 200:
                    soup = BeautifulSoup(resp.content, 'html.parser')
                    download_links = soup.find_all('a', href=lambda href: href and 'fshare.vn' in href)
                    for link_div in download_links:
                        link = link_div.get('href')
                        if '/folder/' in link:
                            files = self._get_folder_files(link, search_ep)
                            results.extend(files)
                        else:
                            file_info = self._get_file_info(link, search_ep)
                            if file_info and year in file_info.get('title'):
                                results.append(file_info)
            main_cache.set(cache_key, results, expiration=timedelta(hours=24))
        results = self._remove_duplicate(results)
        result.extend(results)
        return results

    def _search_hdvn(self, title, result, **kwargs):
        results = []
        fshare_links = self.hdvn.search(title, **kwargs)
        fshare_links = list(dict.fromkeys(fshare_links)) if fshare_links else []
        if len(fshare_links) > 2:
            fshare_links = fshare_links[:2]
        for link in fshare_links:
            if '/folder/' in link:
                files = self._get_folder_files(link)
                results.extend(files)
            else:
                file = self._get_file_info(link)
                if file:
                    results.append(file)
        results = self._remove_duplicate(results)
        result.extend(results)
        return results

    def _get_folder_files(self, url, search_ep=None):
        if not self.token or not self.sessionid:
            return []
        max_folders = 4
        cache_key = f"fshare_folder_{url}"
        cache_data = main_cache.get(cache_key)
        resp_data = []
        if cache_data:
            resp_data = cache_data
        else:
            req_headers = self.headers
            req_headers.update({
                'Content-Type': 'application/json',
                'Cookie': 'session_id=' + self.sessionid,
            })
            results = []
            resp = self.session.post(BASE_URL + '/fileops/getFolderList', headers=req_headers, data=json.dumps({
                'token': self.token,
                'url': url,
                'dirOnly': 0,
                'pageIndex': 0,
                'limit': 500,
            }))
            if resp.status_code == 200:
                resp_data = resp.json() if resp else []
                main_cache.set(cache_key, results, expiration=timedelta(days=1))
        total_folders = len([f for f in resp_data if f.get('type') == '0'])
        should_get_folders = total_folders < max_folders
        folders_name = [f.get('name').lower() for f in resp_data if f.get('type') == '0']
        if not should_get_folders and any(f.startswith('season') for f in folders_name):
            should_get_folders = True
        if search_ep:
            resp_data = [f for f in resp_data if search_ep in f.get('name')]
        for item in resp_data:
            if should_get_folders and item.get('type') == '0':
                results.extend(self._get_folder_files(item.get('furl')))
            elif item.get('type') != '0':
                results.append({
                    'title': re.sub(CLEAN_REGEX, '', item.get('name')).strip(),
                    'link': item.get('furl'),
                    'size': item.get('size')
                })
        return results

    def _get_file_info(self, url, search_ep=None):
        if not self.token or not self.sessionid:
            return False
        cache_key = f'fshare_file_{url}'
        cache_data = main_cache.get(cache_key)
        if cache_data:
            resp_data = {}
        else:
            req_headers = self.headers
            req_headers.update({
                'Content-Type': 'application/json',
                'Cookie': 'session_id=' + self.sessionid,
            })
            resp = self.session.post(BASE_URL + '/fileops/get', headers=req_headers, data=json.dumps({
                'token': self.token,
                'url': url,
            }))
            if resp.status_code == 200:
                resp_data = resp.json() if resp else {}
                main_cache.set(cache_key, resp_data, expiration=timedelta(days=1))
        if resp_data:
            name = resp_data.get('name')
            if not re.match(VIDEO_REGEX, name):
                return False
            if search_ep and not search_ep in name:
                return False
            return {
                'title': re.sub(CLEAN_REGEX, '', name).strip(),
                'size': resp_data.get('size'),
                'link': url,
            }
        return False

    def _remove_duplicate(self, results, key='link'):
        return list({ i[key]: i for i in reversed(results) }.values())

    def get_download_link(self, link):
        if not self.login():
            return False
        req_headers = self.headers
        req_headers.update({
            'Authorization': 'Bearer efdf39c90189ddfbff339ae344c28db5f6c11885',
            'Content-Type': 'application/json',
            'Cookie': 'session_id=' + self.sessionid,
        })
        resp = self.session.post(BASE_URL + '/session/download', headers=req_headers, data=json.dumps({
            'zipfloag': 0,
            'url': link,
            'password': '',
            'token': self.token,
        }))
        if resp.status_code == 200:
            resp_data = resp.json() if resp else {}
            return resp_data.get('location')
        return False

    def unrestrict_link(self, link):
        return self.get_download_link(link)

    def get_hosts(self):
        return {
            'Fshare': [
                'hoster',
            ],
        }


class HDVNSearch:

    def __init__(self):
        self.session = Session()

    def search(self, title, **kwargs):
        year = kwargs.get('year')
        results = []
        cache_key = f"hdvn_{title}_{year}"
        cache_data = main_cache.get(cache_key)
        if cache_data:
            return cache_data
        headers = {
            "authority": "www.hdvietnam.xyz",
            "accept": "application/json, text/javascript, */*; q=0.01",
            "content-type": "application/x-www-form-urlencoded; charset=UTF-8",
            "cookie": HDVN_COOKIE,
            "origin": "https://www.hdvietnam.xyz",
            "referer": "https://www.hdvietnam.xyz/search/",
            "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36 Edg/115.0.0.0",
            "x-ajax-referer": "https://www.hdvietnam.xyz/search/",
            "x-requested-with": "XMLHttpRequest",
        }
        _xf_token = self._get_xftoken()
        req_data = {
            'keywords': f'"{title}" {year}',
            'title_only': '1',
            'users': '',
            'date': '',
            'nodes[]': ['6', '337', '116', '33', '57', '123', '149', '150'],
            'child_nodes': '1',
            'order': 'date',
            '_xfToken': _xf_token,
            '_xfRequestUri': '/search/',
            '_xfNoRedirect': '1',
            '_xfResponseType': 'json'
        }
        resp = self.session.post(HDVN_URL + '/search/search', headers=headers, data=req_data)
        if resp.status_code == 200:
            resp_data = resp.json() if resp else {}
            if "_redirectTarget" in resp_data:
                results = self._get_list_items(resp_data.get("_redirectTarget"), headers, **dict(
                    title=title,
                    year=kwargs.get('year'),
                    season=kwargs.get('season'),
                    episode=kwargs.get('episode'),
                ))
        main_cache.set(cache_key, results, expiration=timedelta(days=30 if kwargs.get('season') else 1))
        return results

    def _get_list_items(self, url, headers, **kwargs):
        title = kwargs.get('title')
        year = kwargs.get('year')
        resp = self.session.get(url, headers=headers)
        link_results = []
        if resp.status_code == 200:
            soup = BeautifulSoup(resp.content, 'html.parser')
            divs = soup.find("ol", class_="searchResultsList")
            if not divs:
                return []
            threads = soup.find_all('li', id=lambda value: value and value.startswith('thread'))
            for thread in threads:
                h3 = thread.find('h3', class_='title')
                name = re.sub(CLEAN_BRACKET_REGEX, '', h3.get_text()).strip()
                name = re.sub(CLEAN_REGEX, '', name).strip()
                href = f"{HDVN_URL}/{h3.a.get('href')}"
                if title in name and year in name:
                    link_results.append(href)

        results = []
        if link_results:
            results.extend(self._get_link_content(link_results[0], headers))
        return results

    def _get_link_content(self, url, headers):
        resp = self.session.get(url, headers=headers)
        if resp.status_code == 200:
            soup = BeautifulSoup(resp.content, 'html.parser')
            span_tag = soup.find('span', class_='LikeLabel')
            if span_tag:
                if span_tag.get_text() == 'Cảm ơn':
                    a_tag = soup.find('a', class_='LikeLink item control like')
                    url_post = f"{HDVN_URL}/{a_tag['href']}"
                    self._do_like(url_post)
                    response = self.session.get(url, headers=headers)
                    if response.status_code == 200:
                        soup = BeautifulSoup(response.content, "html.parser")
            div = soup.find("ol", class_="messageList")
            if div:
                content = div.find("div", class_="messageContent")
                links = content.find_all("a")
                urls = [l.get('href') for l in links if 'fshare.vn' in l.get('href')]
                if urls:
                    return urls
        return []

    def _do_like(self, url):
        headers = {
            "authority": "www.hdvietnam.xyz",
            "accept": "application/json, text/javascript, */*; q=0.01",
            "content-type": "application/x-www-form-urlencoded; charset=UTF-8",
            "cookie": HDVN_COOKIE,
            "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36 Edg/115.0.0.0",
            "x-requested-with": "XMLHttpRequest"
        }
        _xf_token = self._get_xftoken()
        req_data = {
            "_xfNoRedirect": "1",
            "_xfToken": _xf_token,
            "_xfResponseType": "json"
        }
        self.session.post(url, headers=headers, data=req_data)

    def _get_xftoken(self):
        headers = {
            "authority": "www.hdvietnam.xyz",
            "cookie": HDVN_COOKIE,
            "user-agent": HDVN_USER_AGENT
        }
        response = self.session.get(HDVN_URL, headers=headers)
        if response.status_code == 200:
            regex = r"\"_xfToken\" value=\"(.*)\""
            match = re.search(regex, response.text)
            return match.group(1)
