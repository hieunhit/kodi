from apis.fshare_api import FshareAPI
from fenom import source_utils

class source:
    priority = 1
    pack_capable = False
    hasMovies = True
    hasEpisodes = True

    def __init__(self):
        self.language = ['en', 'vi']
        self.fshare_api = FshareAPI()

    def sources(self, data, hostDict):
        sources = []
        if not data: return sources
        append = sources.append

        try:
            title = data['tvshowtitle'] if 'tvshowtitle' in data else data['title']
            title = title.replace('&', 'and').replace('Special Victims Unit', 'SVU').replace('/', ' ')
            episode_title = data['title'] if 'tvshowtitle' in data else None
            aliases = data.get('aliases')
            year = data.get('year')
            season = data.get('season')
            episode = data.get('episode')
            hdlr = 'S%02dE%02d' % (int(season), int(episode)) if 'tvshowtitle' in data else year
            results = self.fshare_api.search(title, year=year, season=season, episode=episode)

            for item in results:
                url = item.get('link')
                name = source_utils.clean_name(item['title'])
                if not source_utils.check_title(title, aliases, name, hdlr, year): continue
                name_info = source_utils.info_from_name(name, title, year, hdlr, episode_title)
                quality, info = source_utils.get_release_quality(name_info, url)
                try:
                    dsize, isize = source_utils.convert_size(float(item["size"]), to='GB')
                    info.insert(0, isize)
                except: dsize = 0
                info = ' | '.join(info)

                append({'provider': 'fshare', 'source': 'hoster', 'name': name, 'name_info': name_info,
                        'quality': quality, 'language': 'vi', 'url': url, 'info': info,
                        'direct': True, 'debridonly': False, 'size': dsize})
        except:
            source_utils.scraper_error('FSHARE')

        return sources
