import os
import re
import difflib
import shutil
import json
import xbmcvfs
from random import randint
from requests import Session
from datetime import timedelta
from zipfile import ZipFile
from caches.main_cache import main_cache
from modules.kodi_utils import notification, sleep, delete_file, rename_file, logger
from modules.agent_lists import FIRST_THOUSAND_OR_SO_USER_AGENTS as AGENT_LIST
from modules.meta_lists import language_choices

BASE_URL = "https://api.subsource.net/api"
timeout = 10
exts = [".idx", ".sup", ".srt", ".sub", ".str", ".ass"]

class SubsourceAPI:

    def __init__(self):
        self.session = Session()
        self.headers = {
            'User-Agent': AGENT_LIST[randint(0, len(AGENT_LIST) - 1)],
            'Accept': 'application/json, text/plain, */*',
            'Accept-Language': 'en-US,en;q=0.5',
            'Accept-Encoding': 'gzip, deflate',
            'Content-Type': 'application/json',
            'Origin': 'https://subsource.net',
            'Priority': 'u=1, i',
            'Referer': 'https://subsource.net/',
            'Connection': 'keep-alive',
            'Upgrade-Insecure-Requests': '1',
            'Cache-Control': 'max-age=0'
        }

    def search(self, title, imdb_id, language, season=None, episode=1, **kwargs):
        language_name = next(item[0] for item in language_choices.items() if item[1] == language)
        year = kwargs.get('year')
        cache_name = f"subsource_{imdb_id or title}_{year}"
        search_imdb_id = imdb_id
        if imdb_id and not imdb_id.startswith('tt'):
            search_imdb_id = f"tt{imdb_id}"
        if season:
            cache_name += f'_s{season}e{episode}'
        cache = main_cache.get(cache_name)
        if cache:
            return cache
        response = self._req(f'{BASE_URL}/searchMovie', params=json.dumps(dict(
            query=f"{title} {year}" if year else title,
        )), method="POST", retry=True)
        resp = response.json() if response else {}
        if not resp.get('success'):
            return []
        metadata = dict(
            title=title,
            year=year,
        )
        subtitles = []
        for item in resp['found']:
            if search_imdb_id == item.get('imdb') or self.is_match_item(item, metadata):
                req_data = dict(
                    movieName=item['linkName'],
                    langs=[language_name],
                )
                if season:
                    req_data['season'] = f"season-{season}"
                response = self._req(f'{BASE_URL}/getMovie', params=json.dumps(req_data), method="POST", retry=True)
                resp_movie = response.json() if response else {}
                if not resp_movie.get('success'):
                    continue
                resp_subs = resp_movie.get('subs', [])
                for sub in resp_subs:
                    if sub.get('lang') != language_name:
                        continue
                    if season:
                        se = re.search(r"[Ss](\d{2})[Ee](\d{2})", sub['releaseName'])
                        if se:
                            result_season = int(se.group(1))
                            result_episode = int(se.group(2))
                            if (result_season and season == result_season) and (result_episode and episode == result_episode):
                                self._add_sub(subtitles, sub, language)
                            else:
                                continue
                    else:
                        self._add_sub(subtitles, sub, language)

        main_cache.set(cache_name, subtitles, expiration=timedelta(hours=24))
        return subtitles
    
    def _add_sub(self, subtitles, sub, language):
        download_link = f"{BASE_URL}/downloadSub/{sub['subId']}"
        subtitles.append(dict(
            SubFileName=sub['releaseName'] + '.srt',
            SubLanguageID=language,
            MovieReleaseName=sub['releaseName'],
            SubSumCD="1",
            SubFormat="srt",
            ZipDownloadLink=download_link,
        ))

    def download(self, url, filepath, temp_zip, temp_path, final_path):
        download_link, sub_id = url.rsplit('/', 1)
        req_params = dict(
            id=sub_id
        )
        result = self._req(download_link, params=json.dumps(req_params), method="POST", stream=True, retry=True)
        with open(temp_zip, 'wb') as f:
            shutil.copyfileobj(result.raw, f)
        with ZipFile(temp_zip, 'r') as zip_file:
            zip_file.extractall(filepath)
        delete_file(temp_zip)
        for file_ in xbmcvfs.listdir(filepath)[1]:
            ufile = file_
            file_ = os.path.join(filepath, ufile)
            for ext in exts:
                if os.path.splitext(ufile)[1] == ext:
                    final_path.replace('.srt', ext)
                    rename_file(file_, final_path)
        return final_path

    def is_match_item(self, item, metadata):
        return self.is_match_year(item, metadata) and self.is_match_title(item['title'], metadata['title'])

    def is_match_year(self, item, metadata):
        return metadata['year'] is None or str(item['releaseYear']) == metadata['year']

    def is_match_title(self, query, title):
        return difflib.SequenceMatcher(None, query, title).ratio() > 0.7

    def _req(self, url, params=None, method="GET", stream=False, retry=False):
        response = self.session.request(method,
                                        url,
                                        params=params if method == "GET" else None,
                                        data=params if method != "GET" else None,
                                        headers=self.headers,
                                        stream=stream,
                                        timeout=timeout)
        if 200 == response.status_code:
            return response
        elif 429 == response.status_code and retry:
            notification(32740, 3000)
            sleep(10000)
            return self._req(url, params=params, method=method, stream=stream, retry=retry)
        else: return
