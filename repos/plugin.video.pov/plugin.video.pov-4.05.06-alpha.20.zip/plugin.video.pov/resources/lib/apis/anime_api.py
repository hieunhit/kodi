import re
from urllib.parse import urlparse, parse_qs
from bs4 import BeautifulSoup
from requests import Session
from caches.main_cache import main_cache
from modules.kodi_utils import logger

DEFAULT_TIMEOUT = 30

class Anime47Api:
    base_url = 'https://anime47.blog'
    user_agent = 'Dalvik/2.1.0 (Linux; U; Android 13; Pixel 7 Pro Build/TQ1A.335336.002)'

    def __init__(self):
        self.session = Session()

    def search(self, title, **kwargs):
        cache_key = f"anime47_{title}_{kwargs.get('year')}"
        hdlr = 'S%02dE%02d' % (int(kwargs.get('season')), int(kwargs.get('episode'))) if kwargs.get('season') else kwargs.get('year')
        if kwargs.get('season'):
            cache_key += f"_{kwargs.get('season')}"
        try:
            link = main_cache.get(cache_key)
            if not link:
                link = self._search_item(title, **kwargs)
                if not link:
                    return
                main_cache.set(cache_key, link)
            episode_id = self._search_episode(link, **kwargs)
            if episode_id:
                play_url = self._get_play_link(episode_id)
                if play_url:
                    return {
                        'title': f"{title} {hdlr} 1080p Webdl ANIME47",
                        "link": play_url,
                        "check": False,
                        "provider": "anime47",
                    }
        except Exception as e:
            logger('ANIME47', f'Error: {e}')
            return

    def _search_item(self, title, **kwargs):
        def _search(title):
            resp = self.session.get(f"{self.base_url}/tim-nang-cao/?keyword={title.replace(' ', '+')}&nam=&season=&status=&sapxep=1",
                                    headers={
                                        'User-Agent': self.user_agent,
                                        'Referer': self.base_url
                                    },
                                    timeout=DEFAULT_TIMEOUT)
            resp.raise_for_status()
            soup = BeautifulSoup(resp.content, 'html.parser')
            return soup.select('ul.last-film-box a')

        title_alias = kwargs.get('alias')
        search_title = title_alias or title
        result = []
        items = _search(search_title)
        if not items:
            if title_alias:
                items = _search(title)
        if not items:
            return result
        for k in items:
            item_name = k['title'].replace('-', ' ')
            item_name_lower = item_name.lower()
            url = re.sub(r'^\./', self.base_url + '/', k['href'])
            if title.replace('-', ' ').lower() in item_name_lower or title_alias.lower() in item_name_lower:
                result.append(url)

        if result:
            return self._get_item_link(result[0], **kwargs)

    def _get_item_link(self, url, **kwargs):
        season = kwargs.get('season')
        resp = self.session.get(url, headers={
            'User-Agent': self.user_agent,
        }, timeout=DEFAULT_TIMEOUT)
        link = None
        soup = None
        if resp.status_code == 200:
            soup = BeautifulSoup(resp.content, 'html.parser')
            item_link = None
            if season and int(season) > 1:
                item_info = soup.find('div', id='div1')
                if item_info and item_info.text:
                    table = item_info.find('table')
                    for row in table.find_all('tr')[1:]:
                        tds = row.find_all('td')
                        td_season = tds[1].get_text().strip()
                        if td_season.lower() == f'phần {season}':
                            item_link = tds[1].find('a')['href']
                            break
            if item_link:
                resp = self.session.get(item_link, headers={
                    'User-Agent': self.user_agent,
                })
                soup = BeautifulSoup(resp.content, 'html.parser') if resp.status_code == 200 else None
        if soup:
            watch_btn = soup.find('a', id='btn-film-watch')
            if watch_btn:
                link = re.sub(r'^\./', self.base_url + '/', watch_btn['href'])
        return link

    def _search_episode(self, url, **kwargs):
        def _get_episode(div, episode=None):
            result_id = None
            for a in div.find_all('a'):
                if not episode:
                    result_id = a.get('data-episode-id')
                    break
                ep_str = re.sub('[^0-9]','', a.get('data-episode-name'))
                if ep_str == str(episode).zfill(len(ep_str)):
                    result_id = a.get('data-episode-id')
                    break
            return result_id

        season = kwargs.get('season')
        episode = kwargs.get('episode')
        flatten_episode = kwargs.get('flatten_episode')
        resp = self.session.get(url, headers={
            'User-Agent': self.user_agent,
        })
        result_id = None
        if resp.status_code == 200:
            soup = BeautifulSoup(resp.content, 'html.parser')
            eps_divs = soup.select('div.server div.episodes')
            seasons_divs = soup.select('div.server div.name')
            total_sections = len(eps_divs)
            if total_sections == 0:
                return result_id
            if season:
                if total_sections == 1 or int(season) == 1 and total_sections > 1:
                    result_id = _get_episode(eps_divs[0], episode)
                else:
                    find_season = [s for s in seasons_divs if s.get_text().strip().lower() == f'phần {season}']
                    season_div = seasons_divs[0] if seasons_divs else None
                    if find_season:
                        season_div = find_season[0]
                    eps_div = eps_divs[0]
                    if season_div:
                        eps_div = season_div.find_next_sibling('div', class_='episodes')
                    result_id = _get_episode(eps_div, flatten_episode)
                    if not result_id:
                        result_id = _get_episode(eps_div, episode)
            else:
                result_id = _get_episode(eps_divs[0])
        return result_id

    def _get_play_link(self, episode_id):
        req_url = f'{self.base_url}/player/player.php'
        req_data = {
            'ID': episode_id,
            'SV': '4',
            'SV4': '4',
        }
        resp = self.session.post(req_url, data=req_data, headers={
            'User-Agent': self.user_agent,
            'X-Requested-With': 'XMLHttpRequest'
        })
        parts = []
        if resp.status_code == 200:
            play_link = re.search(r'"file".*?"(.*?)"', resp.text)[1]
            play_link = re.sub(r'\s+', '%20', play_link.strip(), flags=re.UNICODE)
            play_type = re.search(r'"type".*?"(.*?)"', resp.text)[1]
            if play_type.strip() == 'hls':
                parts.append('hls')
            parts.append(play_link)
            if 'subtitles' in resp.text:
                sub = re.findall(r'file:.*?"(.*?\.vtt)"', resp.text)[-1]
                parts.append(f'{self.base_url}{sub}')
            parts.append(f'Origin={self.base_url}&User-Agent={self.user_agent}')
        return '|'.join(parts)

class HH3DApi:
    base_url = 'https://hoathinh3dtq.com'
    user_agent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36 Edg/115.0.0.0"

    def __init__(self):
        self.session = Session()

    def search(self, title, **kwargs):
        try:
            cache_key = f"hh3d_{title}_{kwargs.get('year')}"
            hdlr = 'S%02dE%02d' % (int(kwargs.get('season')), int(kwargs.get('episode'))) if kwargs.get('season') else kwargs.get('year')
            if kwargs.get('season'):
                cache_key += f"_{kwargs.get('season')}"
            item_link = main_cache.get(cache_key)
            if not item_link:
                item_link = self._search_item(title, **kwargs)
                if not item_link:
                    return
                main_cache.set(cache_key, item_link)
            if not item_link:
                return
            ep_info = self._search_episode(item_link[0], **kwargs)
            if ep_info:
                play_link = self._get_play_link(ep_info)
                if play_link:
                    return {
                        'title': f"{title} {hdlr} 1080p Webdl HOATHINH3D",
                        "link": play_link,
                        "check": False,
                        "provider": "hoathinh3d",
                    }
        except Exception as e:
            logger('HH3D', f'Error: {e}')
            return

    def _search_item(self, title, **kwargs):
        title_alias = kwargs.get('alias')
        season = kwargs.get('season')
        search_title = title_alias or title
        resp = self.session.get(f"{self.base_url}/wp-content/themes/halimmovies/halim-ajax.php", data={
            'action': 'halim_ajax_live_search',
            'search': search_title,
        }, headers={
            'Origin': self.base_url,
            'User-Agent': self.user_agent,
            'X-Requested-With': 'XMLHttpRequest',
        }, timeout=DEFAULT_TIMEOUT)
        link = None
        result = []
        resp.raise_for_status()
        soup = BeautifulSoup(resp.content, 'html.parser')
        items = soup.select('li.exact_result a')
        for item in items:
            item_name = item.find('span', class_="label").get_text().strip().lower()
            en_name = item.find('span', class_="enName").get_text().strip().lower()
            if search_title.lower() in item_name or search_title.lower() in en_name:
                link = item['href']
                break
        if season and link:
            resp = self.session.get(link, headers={
                'Origin': self.base_url,
                'User-Agent': self.user_agent,
            })
            resp.raise_for_status()
            soup = BeautifulSoup(resp.content, 'html.parser')
            seasons = soup.select('ul.list-movies-part a')
            for s in seasons:
                if f'phần {season}' in s['title'].lower().strip():
                    link = s['href']
        if link:
            result.append(link)
        return result

    def _search_episode(self, url, **kwargs):
        season = kwargs.get('season')
        episode = kwargs.get('episode')
        resp = self.session.get(url, headers={
            'User-Agent': self.user_agent,
            'Origin': self.base_url,
        })
        result = None
        resp.raise_for_status()
        soup = BeautifulSoup(resp.content, 'html.parser')
        eps = (soup.select('ul.halim-list-eps li') or [])[::-1]
        ends_idx = [i for i, e in enumerate(eps) if 'end' in e.get_text().lower()]
        ep = None
        if season and int(season) == 1:
            for e in eps:
                a = e.find('a')
                ep_str = re.sub(r'^[0-9]', '', a['title'])
                if ep_str == episode.zfill(len(ep_str)):
                    ep = e
        if not ep and not season or not ends_idx:
            if len(eps) == 1 and not episode:
                ep = eps[0]
            elif eps and episode and len(eps) >= int(episode):
                ep = eps[int(episode) - 1]
        if ends_idx and not ep and season:
            seasons = []
            last_idx = 0
            ends_idx.append(-1)
            for i in ends_idx:
                seasons.append(eps[last_idx:i])
                last_idx = i + 1
            if int(season) <= len(seasons):
                _eps = seasons[int(season) - 1]
                if len(_eps) >= int(episode):
                    ep = _eps[int(episode) - 1]
        if ep:
            ep_info = ep.find('span')
            result = {
                'post_id': ep_info['data-post-id'],
                'server_id': ep_info['data-server'],
                'subsv_id': '',
                'episode_slug': ep_info['data-episode-slug'],
            }
        return result

    def _get_play_link(self, ep_info):
        resp = self.session.get(f"{self.base_url}/wp-content/themes/halimmovies/player.php", params=ep_info, headers={
            'Origin': self.base_url,
            'User-Agent': self.user_agent,
            'X-Requested-With': 'XMLHttpRequest',
        })
        parts = []
        resp.raise_for_status()
        play_link = re.search(r'\\"file\\".*?\\"(.*?)\\"', resp.text)[1]
        play_link = re.sub(r'\s+', '%20', play_link.strip(), flags=re.UNICODE).replace('\\/', '/')
        play_type = re.search(r'\\"type\\".*?\\"(.*?)\\"', resp.text)[1]
        if play_type.strip() == 'hls':
            parts.append('hls')
        parts.append(play_link)
        return '|'.join(parts)

class AnimeHayApi:
    base_url = 'https://animehay.run'
    user_agent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36 Edg/115.0.0.0"

    def __init__(self):
        self.session = Session()

    def search(self, title, **kwargs):
        try:
            hdlr = 'S%02dE%02d' % (int(kwargs.get('season')), int(kwargs.get('episode'))) if kwargs.get('season') else kwargs.get('year')
            cache_key = f"animehay_{title}_{kwargs.get('year')}"
            if kwargs.get('season'):
                cache_key += f"_{kwargs.get('season')}"
            item_link = main_cache.get(cache_key)
            if not item_link:
                item_link = self._search_item(title, **kwargs)
                if not item_link:
                    return
                main_cache.set(cache_key, item_link)
            ep_link = self._search_episode(item_link[0], **kwargs)
            if ep_link:
                play_link = self._get_play_link(ep_link)
                if play_link:
                    return {
                        'title': f"{title} {hdlr} 1080p Webdl ANIMEHAY",
                        "link": play_link,
                        "check": False,
                        "provider": "animehay",
                    }
        except Exception as e:
            logger('ANIMEHAY', f'Error: {e}')
            return

    def _search_item(self, title, **kwargs):
        def _search(title):
            resp = self.session.get(f"{self.base_url}/tim-kiem/\"{title.lower()}\".html", headers={
                'User-Agent': self.user_agent,
            }, timeout=DEFAULT_TIMEOUT)
            resp.raise_for_status()
            soup = BeautifulSoup(resp.content, 'html.parser')
            return soup.select('div.movies-list div.movie-item')

        title_alias = kwargs.get('alias')
        season = kwargs.get('season')
        search_title = title_alias or title
        result = []
        items = _search(search_title)
        if not items:
            if title_alias:
                items = _search(title)
        if not items:
            return result
        found_idx = 0
        if len(items) > 1:
            found_idx = None
            for i, it in enumerate(items):
                name = it.find('div', class_="name-movie").get_text().strip().lower()
                if search_title.lower() in name or title.lower() in name:
                    found_idx = i
                    break
        if found_idx is None:
            return
        links = items[found_idx].find_all('a')
        for l in links:
            if 'thong-tin-phim' in l['href']:
                link = l['href']
                break
        if season and int(season) > 1 and link:
            resp = self.session.get(link, headers={
                'User-Agent': self.user_agent,
            })
            resp.raise_for_status()
            soup = BeautifulSoup(resp.content, 'html.parser')
            seasons = soup.select('div.bind_movie a')
            for s in seasons:
                if f'phần {season}' in s['title'].lower().strip():
                    link = s['href']
        if link:
            result.append(link)
        return result

    def _search_episode(self, url, **kwargs):
        def _find_ep_flatten(ep_divs, episode):
            link = None
            for ep in ep_divs:
                ep_str = re.sub('[^0-9]', '', ep['title'].split('-')[0]).strip()
                if ep_str == str(episode).zfill(len(ep_str)):
                    link = ep['href']
                    break
            return link

        episode = kwargs.get('episode')
        flatten_episode = kwargs.get('flatten_episode')
        resp = self.session.get(url, headers={
            'User-Agent': self.user_agent,
        })
        resp.raise_for_status()
        soup = BeautifulSoup(resp.content, 'html.parser')
        eps = soup.select('div.list-item-episode a')
        link = None
        if len(eps) >= 1 and not episode:
            link = eps[0]['href']
        else:
            link = _find_ep_flatten(eps, flatten_episode)
            if not link:
                link = _find_ep_flatten(eps, episode)

        return link

    def _get_play_link(self, url):
        resp = self.session.get(url, headers={
            'User-Agent': self.user_agent,
        }, timeout=DEFAULT_TIMEOUT)
        resp.raise_for_status()
        playable_link = None
        video_link = None
        video_links = re.findall(r'id=".*".*src\s*=\s*"(.*?)"', resp.text)
        for v_link in video_links[::-1]:
            if v_link and v_link.startswith('http') and self.base_url in v_link:
                playable_link = v_link
                break
        if playable_link:
            resp = self.session.get(playable_link, headers={
                'User-Agent': self.user_agent,
            }, timeout=DEFAULT_TIMEOUT)
            resp.raise_for_status()
            parsed_url = urlparse(playable_link)
            video_id = parse_qs(parsed_url.query)['id'][0]
            video_link = re.search(r'playlist\s*=\s*`(.*?)`;', resp.text)[1]
            video_link = video_link.replace('${id}', video_id)
        else:
            playable_link = re.search(r"\s*tik:\s*?'(.*?)'", resp.text)[1]
            if playable_link.startswith('http'):
                video_link = playable_link
        if not video_link:
            return
        return f"hls|{video_link}|Accept=*/*&Origin={self.base_url}&Referer={self.base_url}/&User-Agent={self.user_agent}"
