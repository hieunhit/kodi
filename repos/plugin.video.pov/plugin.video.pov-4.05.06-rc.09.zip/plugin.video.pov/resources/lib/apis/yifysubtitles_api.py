import os
import shutil
import xbmcvfs
import re
from random import randint
from bs4 import BeautifulSoup
from requests import Session
from datetime import timedelta
from caches.main_cache import main_cache
from modules.agent_lists import FIRST_THOUSAND_OR_SO_USER_AGENTS as AGENT_LIST
from modules.meta_lists import language_choices
from modules.kodi_utils import notification, sleep, delete_file, rename_file
from zipfile import ZipFile

BASE_URL = 'https://yifysubtitles.ch'
timeout = 20
exts = [".idx", ".sup", ".srt", ".sub", ".str", ".ass"]

class YifySubtitlesAPI:

    def __init__(self):
        self.session = Session()
        self.headers = {
            'User-Agent': AGENT_LIST[randint(0, len(AGENT_LIST) - 1)],
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Accept-Language': 'en-US,en;q=0.5',
            'Accept-Encoding': 'gzip, deflate',
            'DNT': '1',
            'Connection': 'keep-alive',
            'Upgrade-Insecure-Requests': '1',
            'Cache-Control': 'max-age=0'
        }

    def search(self, title, imdb_id, language_code, season=None, episode=None, **kwargs):
        if not imdb_id or season: return
        # search_year = kwargs.get('year')
        search_imdb_id = imdb_id
        if not imdb_id.startswith('tt'):
            search_imdb_id = f'tt{imdb_id}'
        language = next(item[0] for item in language_choices.items() if item[1] == language_code)

        cache_name = 'yifysubtitles_%s_%s' % (search_imdb_id or title, language_code)
        cache = main_cache.get(cache_name)
        if cache:
            return cache

        response = self._get(f'{BASE_URL}/movie-imdb/{search_imdb_id}', retry=True, **dict(
            allow_redirects=False,
        ))
        subtitles = []
        if not response:
            return subtitles
        soup = BeautifulSoup(response.content, 'html.parser')
        tbl = soup.find('table', {'class': 'other-subs'})
        tbl_body = tbl.find('tbody') if tbl else None
        rows = tbl_body.findAll('tr') if tbl_body else []
        for row in rows:
            td = row.findAll('td')
            sub_lang = td[1].text
            if sub_lang == language:
                release_name = re.sub(r'^\nsubtitle ', '', td[2].text).split('\n', 1)[0]
                # try:
                #     year = re.search(r"(?:[0-9]{4})", s)[0]
                # except: year = None
                # if search_year and year and year != search_year:
                #     continue
                sub_id = row.get('data-id')
                download_page = td[2].find('a').get('href')
                subtitles.append(dict(
                    SubFileName=sub_id,
                    SubLanguageID=language_code,
                    MovieReleaseName=release_name,
                    SubSumCD="1",
                    SubFormat="srt",
                    ZipDownloadLink=f'{BASE_URL}{download_page.replace("subtitles/", "subtitle/")}.zip',
                ))

        main_cache.set(cache_name, subtitles, expiration=timedelta(hours=24))
        return subtitles


    def download(self, url, filepath, temp_zip, temp_path, final_path):
        result = self._get(url, stream=True, **dict(
            referer=url.replace('subtitle/', 'subtitles/').replace('.zip', '')
        ))
        with open(temp_zip, 'wb') as f:
            result.raw.decode_content
            shutil.copyfileobj(result.raw, f)
        with ZipFile(temp_zip, 'r') as zip_file: zip_file.extractall(filepath)
        delete_file(temp_zip)
        for file_ in xbmcvfs.listdir(filepath)[1]:
            ufile = file_
            file_ = os.path.join(filepath, ufile)
            for ext in exts:
                if os.path.splitext(ufile)[1] == ext:
                    final_path.replace('.srt', ext)
                    rename_file(file_, final_path)
        return final_path

    def _get(self, url, params=None, stream=False, retry=False, **kwargs):
        get_headers = self.headers
        get_headers.update({'Referer': BASE_URL})
        if kwargs.get('referer'):
            get_headers.update({'Referer': kwargs.get('referer')})
        response = self.session.get(url, params=params, headers=get_headers, stream=stream)
        if response.status_code == 200: return response
        elif response.status_code == 429 and retry:
            notification(32740, 3000)
            sleep(10000)
            return self._get(url, params=params, stream=stream, retry=retry, **kwargs)
        else: return
