import difflib
import json
import re
import random
from bs4 import BeautifulSoup
from datetime import timedelta
from random import randint
from urllib.parse import urlparse, parse_qs
from threading import Thread
from requests import Session
from caches.main_cache import main_cache
from modules.agent_lists import FIRST_THOUSAND_OR_SO_USER_AGENTS as AGENT_LIST
from modules.kodi_utils import get_setting, set_setting, logger
from modules.utils import no_accent_vietnamese


BASE_URL = 'https://api.fshare.vn/api'
YEAR_REGEX = r"(19|20)\d{2}"
VIDEO_REGEX = r"^.*(mkv|mp4|avi|wmv|flv|mov|mpg|mpeg|3gp|webm|ts|iso)$"
CLEAN_REGEX = r"\((?:[^\)|]*\|)?([^\)|]*)\)"
CLEAN_BRACKET_REGEX = r"\[(?:[^\]|]*\|)?([^\]|]*)\]"
THANKS_CONTENT = ["cảm ơn bạn đã chia sẻ", "ty", "thanks", "tks"]

def clean_search_name(raw_name, **kwargs):
    from fenom import source_utils
    title = kwargs.get('title')
    aliases = kwargs.get('aliases', [])
    season = kwargs.get('season')
    raw_name = no_accent_vietnamese(raw_name.lower())
    name_parts = raw_name.split('-', 1)
    if len(name_parts) == 2:
        for i, n in enumerate(name_parts):
            if title.lower() in n:
                pos = i + 1 if i == 0 else i - 1
                raw_name = raw_name.replace(name_parts[pos], '').strip()
                break
    for alias in aliases:
        _s_lower = alias.lower()
        raw_name = raw_name.replace(_s_lower, title)
        raw_name = raw_name.replace(no_accent_vietnamese(_s_lower), title)
    if season and int(season) == 1:
        start_ep_regexp = r'^e[\s|p]?(\d{1,3})\.'
        raw_name = re.sub(r'\.e[\s|p]?(\d{1,3})\.', r'.S%02dE\1.' % 1, raw_name)
        if re.search(start_ep_regexp, raw_name) and \
            (source_utils.clean_name(title).lower() in raw_name or title.lower() in raw_name):
            raw_name = re.sub(start_ep_regexp, r'%s.S%02dE\1.' % (title, 1), raw_name)
    return raw_name


class FshareAPI:
    search_anime = False

    def __init__(self):
        self.session = Session()
        #self.hdvn = HDVNSearch()
        self.phimnews = PhimNews()
        self.timfshare = TimFshare()
        self.app_key = 'dMnqMMZMUnN5YpvKENaEhdQQ5jxDqddt'
        self.username = get_setting('fshare.username')
        self.password = get_setting('fshare.password')
        self.token = get_setting('fshare.token')
        self.sessionid = get_setting('fshare.sessionid')
        self.headers = {
            'cache-control': 'no-cache',
            'User-Agent': 'kodivietmediaf-K58W6U'
        }
        self.login()

    def login(self):
        if self.token and self.sessionid:
            if self.check_login(self.token, self.sessionid):
                return self.token, self.sessionid
        if not self.username or not self.password:
            return False
        req_data = json.dumps({
            'user_email': self.username,
            'password': self.password,
            'app_key': self.app_key,
        })
        resp = self.session.post(BASE_URL + '/user/login', headers=self.headers, data=req_data, timeout=15)
        if resp.status_code == 200:
            resp_data = resp.json() if resp else {}
            self.token = resp_data.get('token')
            self.sessionid = resp_data.get('session_id')
            set_setting('fshare.token', self.token)
            set_setting('fshare.session', self.sessionid)
            return self.token, self.sessionid
        return False

    def logout(self):
        if not self.token or not self.sessionid:
            return False
        req_headers = self.headers
        req_headers.update(Cookie='session_id=' + self.sessionid)
        self.session.get(BASE_URL + '/user/logout', headers=req_headers, timeout=15)
        return True

    def check_login(self, token, session):
        if not token or not session:
            return False
        req_headers = self.headers
        req_headers.update(Cookie='session_id=' + session)
        resp = self.session.get(BASE_URL + '/user/get', headers=req_headers, timeout=15)
        if resp.status_code == 200:
            return True
        return False

    def search(self, title, **kwargs):
        results = []
        if not self.login():
            return results
        threads = []
        #threads.append(Thread(target=self._search_hdvn, args=(title, results), kwargs=kwargs))
        threads.append(Thread(target=self._search_timfshare, args=(title, results), kwargs=kwargs))
        threads.append(Thread(target=self._search_phimnews, args=(title, results), kwargs=kwargs))
        #threads.append(Thread(target=self._search_phongblack, args=(title, results), kwargs=kwargs))
        threads.append(Thread(target=self._search_thuvienhd, args=(title, results), kwargs=kwargs))
        threads.append(Thread(target=self._search_tvcine, args=(title, results), kwargs=kwargs))

        for t in threads:
            t.start()
        for t in threads:
            t.join()
        results = self._remove_duplicate(results)
        return results

    def _search_phongblack(self, title, result, **kwargs):
        year = kwargs.get('year')
        season = kwargs.get('season')
        search_title = title
        results = []
        try:
            req_headers = {
                'User-Agent': 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36 VietMedia/1.0',
                'Referers': 'http://www.google.com',
            }
            resp = self.session.post("https://phongblack.me/search.php?author=phongblack", params=dict(
                search=search_title,
            ), headers=req_headers, timeout=15)
            if resp.status_code == 200:
                resp_data = resp.json() if resp else {}
                data = [item for item in resp_data.get('items', []) if 'fshare.vn' in item.get('path')]
                for item in data:
                    name = item.get('label')
                    path = item.get('path')
                    url = parse_qs(urlparse(path).query).get('url')[0]
                    name_strip = re.sub(CLEAN_BRACKET_REGEX, '', name).strip()
                    name_strip = re.sub(CLEAN_REGEX, '', name_strip.replace(year, '')).strip()
                    name_strip = re.sub(r'{.+}', ' - ', name_strip)
                    parts = name_strip.split(' - ')
                    title_ratio = 0
                    for p in parts:
                        if title_ratio >= 0.5:
                            continue
                        title_ratio = difflib.SequenceMatcher(
                            None,
                            title,
                            p
                        ).ratio()
                    if title_ratio >= 0.5 or title.lower().replace(' ', '.') in name.lower():
                        if '/folder/' in url:
                            files = self._get_folder_files(url, title=title if title_ratio == 1.0 and season else None)
                            results.extend(files)
                        else:
                            file_info = self._get_file_info(url)
                            if file_info and year in file_info.get('title'):
                                results.append(file_info)
            results = self._remove_duplicate(results)
            result.extend(results)
        except Exception as e:
            logger('FSHARE', f'phongblack error: {e}')
        return results

    def _search_thuvienhd(self, title, result, **kwargs):
        year = kwargs.get('year')
        season = kwargs.get('season')
        results = []
        
        try:
            req_headers = {
                'User-Agent': 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36',
                'Referer': 'http://www.google.com',
            }
            resp = self.session.get('https://thuvienhd.xyz', params={
                'feed': 'fsharejson',
                'search': title,
            }, headers=req_headers, timeout=15)
            if resp.status_code == 200:
                resp_data = resp.json() if resp else []
                for item in resp_data:
                    name = item.get('title')
                    title_ratio = 0
                    for p in name.split('&&', 1):
                        if title_ratio >= 0.8:
                            continue
                        title_ratio = difflib.SequenceMatcher(None, title, p.strip()).ratio()
                    # title_ratio = difflib.SequenceMatcher(None, title, name.split('&&', 1)[1]).ratio()
                    if title_ratio >= 0.8:
                        for link_item in item.get('links', []):
                            url = link_item.get('link')
                            if '/folder/' in url:
                                files = self._get_folder_files(url, title=title if season else None)
                                results.extend(files)
                            else:
                                file_info = self._get_file_info(url)
                                if file_info and year in file_info.get('title'):
                                    results.append(file_info)
            results = self._remove_duplicate(results)
            results = [dict(item, **dict(provider='tvhd')) for item in results]
            result.extend(results)
        except Exception as e:
            logger('FSHARE', f'TVHD error {e}')
        return results

    def _search_tvcine(self, title, result, **kwargs):
        base_url = 'https://thuviencine.com'
        year = kwargs.get('year')
        season = kwargs.get('season')
        cache_key = f"tvcine_{title}_{year}"
        if season:
            cache_key += f"_S{season.zfill(2)}"
        results = []
        cache_data = main_cache.get(cache_key)
        if cache_data:
            results = cache_data
        else:
            try:
                req_headers = {
                    'User-Agent': AGENT_LIST[randint(0, len(AGENT_LIST) - 1)],
                    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                    'Accept-Language': 'en-US,en;q=0.5',
                    'Accept-Encoding': 'gzip, deflate',
                    'DNT': '1',
                    'Connection': 'keep-alive',
                    'Upgrade-Insecure-Requests': '1',
                    'Cache-Control': 'max-age=0'
                }
                link = None
                item_id = None
                resp = self.session.get(base_url, params={'s': title}, headers=req_headers, timeout=15)
                if resp.status_code == 200:
                    soup = BeautifulSoup(resp.content, 'html.parser')
                    div_items = soup.find_all("div", {"id": lambda x: x and x.startswith("post-")})
                    for div in div_items:
                        name = div.find('h2', class_='movie-title').text.strip()
                        if title.lower() not in name.lower():
                            continue
                        link = div.find("a")["href"]
                        item_id = div.get('id').replace('post-', '')
                        if link and item_id:
                            link = f"{base_url}/download?id={item_id}"
                            break
                if link:
                    resp = self.session.get(link, headers=req_headers)
                    if resp.status_code == 200:
                        soup = BeautifulSoup(resp.content, 'html.parser')
                        download_links = soup.find_all('a', href=lambda href: href and 'fshare.vn' in href)
                        for link_div in download_links:
                            link = link_div.get('href')
                            if '/folder/' in link:
                                files = self._get_folder_files(link, title=title if season else None)
                                results.extend(files)
                            else:
                                file_info = self._get_file_info(link)
                                if file_info and year in file_info.get('title'):
                                    results.append(file_info)
                main_cache.set(cache_key, results, expiration=timedelta(hours=24))
            except:
                pass
        results = self._remove_duplicate(results)
        results = [dict(item, **dict(provider='tvcine')) for item in results]
        result.extend(results)
        return results

    # def _search_hdvn(self, title, result, **kwargs):
    #     results = []
    #     fshare_links = self.hdvn.search(title, **kwargs)
    #     fshare_links = list(dict.fromkeys(fshare_links)) if fshare_links else []
    #     # if len(fshare_links) > 2:
    #     #     fshare_links = fshare_links[:2]
    #     for link in fshare_links:
    #         if '/folder/' in link:
    #             files = self._get_folder_files(link)
    #             results.extend(files)
    #         else:
    #             file = self._get_file_info(link)
    #             if file:
    #                 results.append(file)
    #     results = self._remove_duplicate(results)
    #     results = [dict(item, **dict(provider='hdvn')) for item in results]
    #     result.extend(results)
    #     return results

    def _search_timfshare(self, title, result, **kwargs):
        results = self.timfshare.search(title, **kwargs)
        results = self._remove_duplicate([dict(item, **dict(provider='timfshare')) for item in results], 'title')
        result.extend(results)
        return results

    def _search_phimnews(self, title, result, **kwargs):
        results = []
        season = kwargs.get('season')
        fshare_links = self.phimnews.search(title, **kwargs)
        fshare_links = list(dict.fromkeys(fshare_links)) if fshare_links else []
        for link in fshare_links:
            if '/folder/' in link:
                files = self._get_folder_files(link,)
                results.extend(files)
            else:
                file = self._get_file_info(link)
                if file:
                    results.append(file)
        results = self._remove_duplicate(results)
        results = [dict(item, **dict(provider='phimnews')) for item in results]
        result.extend(results)
        return results

    def _get_folder_files(self, url, **kwargs):
        if not self.token or not self.sessionid:
            return []
        search_ep = kwargs.get('search_ep')
        title = kwargs.get('title')
        max_folders = 4
        cache_key = f"fshare_folder_{url}"
        cache_data = main_cache.get(cache_key)
        resp_data = []
        if cache_data:
            resp_data = cache_data
        else:
            req_headers = self.headers
            req_headers.update({
                'Content-Type': 'application/json',
                'Cookie': 'session_id=' + self.sessionid,
            })
            results = []
            resp = self.session.post(BASE_URL + '/fileops/getFolderList', headers=req_headers, data=json.dumps({
                'token': self.token,
                'url': url,
                'dirOnly': 0,
                'pageIndex': 0,
                'limit': 200,
            }), timeout=15)
            if resp.status_code == 200:
                resp_data = resp.json() if resp else []
                main_cache.set(cache_key, results, expiration=timedelta(days=1))
        total_folders = len([f for f in resp_data if f.get('type') == '0'])
        should_get_folders = total_folders < max_folders
        folders_name = [f.get('name').lower() for f in resp_data if f.get('type') == '0']
        if not should_get_folders and any(f.startswith('season') for f in folders_name):
            should_get_folders = True
        if search_ep:
            resp_data = [f for f in resp_data if search_ep in f.get('name')]
        for item in resp_data:
            if should_get_folders and item.get('type') == '0':
                files = self._get_folder_files(item.get('furl'))
                if title is not None:
                    for f in files:
                        f['title'] = re.sub(r"([a-zA-Z]+){8,}(\d{2,3})\.", f"{title}.E\\2.", f['title']).strip()
                        f['title'] = re.sub(r"([a-zA-Z]+){8,}EP(\d{2,3})\.", f"{title}.E\\2.", f['title']).strip()
                        f['title'] = re.sub(r"([a-zA-Z]+){8,}((\d)-)(\d{1,3})\.", f"{title}.S\\3E\\4.", f['title']).strip()
                results.extend(files)
            elif item.get('type') != '0':
                results.append({
                    'title': re.sub(CLEAN_REGEX, '', item.get('name')).strip(),
                    'link': item.get('furl'),
                    'size': item.get('size')
                })
        return results

    def _get_file_info(self, url, search_ep=None):
        if not self.token or not self.sessionid:
            return False
        cache_key = f'fshare_file_{url}'
        cache_data = main_cache.get(cache_key)
        resp_data = {}
        if cache_data:
            resp_data = cache_data
        else:
            req_headers = self.headers
            req_headers.update({
                'Content-Type': 'application/json',
                'Cookie': 'session_id=' + self.sessionid,
            })
            resp = self.session.post(BASE_URL + '/fileops/get', headers=req_headers, data=json.dumps({
                'token': self.token,
                'url': url,
            }), timeout=15)
            if resp.status_code == 200:
                resp_data = resp.json() if resp else {}
                main_cache.set(cache_key, resp_data, expiration=timedelta(days=1))
        if resp_data:
            name = resp_data.get('name')
            if not re.match(VIDEO_REGEX, name):
                return False
            if search_ep and not search_ep in name:
                return False
            return {
                'title': re.sub(CLEAN_REGEX, '', name).strip(),
                'size': resp_data.get('size'),
                'link': url,
            }
        return False

    def _remove_duplicate(self, results, key='size'):
        # r, k = [], []
        # for i in results:
        #     if i[key] not in k:
        #         k.append(i[key])
        #         r.append(i)
        #     logger('fshare', f"{i[key]} {i}")
        # return r
        return list({ i[key]: i for i in reversed(results) }.values())

    def get_download_link(self, link):
        if not self.login():
            return False
        req_headers = self.headers
        req_headers.update({
            'Authorization': 'Bearer efdf39c90189ddfbff339ae344c28db5f6c11885',
            'Content-Type': 'application/json',
            'Cookie': 'session_id=' + self.sessionid,
        })
        resp = self.session.post(BASE_URL + '/session/download', headers=req_headers, data=json.dumps({
            'zipfloag': 0,
            'url': link,
            'password': '',
            'token': self.token,
        }), timeout=15)
        if resp.status_code == 200:
            resp_data = resp.json() if resp else {}
            return resp_data.get('location')
        return False

    def unrestrict_link(self, link):
        if 'fshare' in link:
            return self.get_download_link(link)
        return link

    def get_hosts(self):
        return {
            'Fshare': [
                'hoster',
                'tvhd',
                'tvcine',
                'hdvn',
                'phimnews',
                'timfshare',
            ],
            'webphim': [
                'ophim',
                'nguonc',
                'kkphim',
                'anime47',
                'hoathinh3d',
                'animehay',
            ],
        }


class HDVNSearch:

    def __init__(self):
        self.host = "www.hdvietnam.xyz"
        self.base_url = f"https://{self.host}"
        self.search_nodes = ['6', '337', '116', '33', '57', '123', '149', '150']
        self.HDVN_COOKIE = "xf_user=1983091%2C8cdb6cf90d618349958e40ea9b57b628dffd971c"
        self.USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36 Edg/115.0.0.0"
        self.session = Session()

    def search(self, title, **kwargs):
        year = kwargs.get('year')
        results = []
        cache_key = f"hdvn_{title}_{year}"
        cache_data = main_cache.get(cache_key)
        if cache_data:
            return cache_data
        headers = {
            "authority": self.host,
            "accept": "application/json, text/javascript, */*; q=0.01",
            "content-type": "application/x-www-form-urlencoded; charset=UTF-8",
            "cookie": self.HDVN_COOKIE,
            "origin": self.base_url,
            "referer": f"{self.base_url}/search/",
            "user-agent": self.USER_AGENT,
            "x-ajax-referer": f"{self.base_url}/search/",
            "x-requested-with": "XMLHttpRequest",
        }
        _xf_token = self._get_xftoken()
        req_data = {
            'keywords': f'"{title}" {year}',
            'title_only': '1',
            'users': '',
            'date': '',
            'nodes[]': self.search_nodes,
            'child_nodes': '1',
            'order': 'date',
            '_xfToken': _xf_token,
            '_xfRequestUri': '/search/',
            '_xfNoRedirect': '1',
            '_xfResponseType': 'json'
        }
        try:
            resp = self.session.post(self.base_url + '/search/search', headers=headers, data=req_data, timeout=15)
            if resp.status_code == 200:
                resp_data = resp.json() if resp else {}
                if "_redirectTarget" in resp_data:
                    results = self._get_list_items(resp_data.get("_redirectTarget"), headers, **dict(
                        title=title,
                        year=kwargs.get('year'),
                        season=kwargs.get('season'),
                        episode=kwargs.get('episode'),
                    ))
                    main_cache.set(cache_key, results, expiration=timedelta(days=30 if kwargs.get('season') else 1))
            return results
        except:
            logger('FSHARE', 'Cannot connect to HDVN')
            return []

    def _get_list_items(self, url, headers, **kwargs):
        title = kwargs.get('title')
        year = kwargs.get('year')
        resp = self.session.get(url, headers=headers, timeout=15)
        link_results = []
        if resp.status_code == 200:
            soup = BeautifulSoup(resp.content, 'html.parser')
            divs = soup.find("ol", class_="searchResultsList")
            if not divs:
                return []
            threads = soup.find_all('li', id=lambda value: value and value.startswith('thread'))
            for thread in threads:
                h3 = thread.find('h3', class_='title')
                name = re.sub(CLEAN_BRACKET_REGEX, '', h3.get_text()).strip()
                name = re.sub(CLEAN_REGEX, '', name).strip()
                href = f"{self.base_url}/{h3.a.get('href')}"
                if title.lower() in name.lower() and year in name:
                    link_results.append(href)

        results = []
        if link_results:
            for link in link_results[:2]:
                results.extend(self._get_link_content(link, headers))
        return results

    def _get_link_content(self, url, headers):
        resp = self.session.get(url, headers=headers, timeout=30)
        if resp.status_code == 200:
            soup = BeautifulSoup(resp.content, 'html.parser')
            span_tag = soup.find('span', class_='LikeLabel')
            if span_tag:
                if span_tag.get_text() == 'Cảm ơn':
                    a_tag = soup.find('a', class_='LikeLink item control like')
                    url_post = f"{self.base_url}/{a_tag['href']}"
                    self._do_like(url_post)
                    response = self.session.get(url, headers=headers, timeout=30)
                    if response.status_code == 200:
                        soup = BeautifulSoup(response.content, "html.parser")
            div = soup.find("ol", class_="messageList")
            if div:
                content = div.find("div", class_="messageContent")
                links = content.find_all("a") or []
                urls = [l.get('href') for l in links if 'fshare.vn' in l.get('href')]
                if urls:
                    return urls[:1]
        return []

    def _do_like(self, url):
        headers = {
            "authority": self.host,
            "accept": "application/json, text/javascript, */*; q=0.01",
            "content-type": "application/x-www-form-urlencoded; charset=UTF-8",
            "cookie": self.HDVN_COOKIE,
            "user-agent": self.USER_AGENT,
            "x-requested-with": "XMLHttpRequest"
        }
        _xf_token = self._get_xftoken()
        req_data = {
            "_xfNoRedirect": "1",
            "_xfToken": _xf_token,
            "_xfResponseType": "json"
        }
        self.session.post(url, headers=headers, data=req_data, timeout=15)

    def _get_xftoken(self):
        headers = {
            "authority": self.host,
            "cookie": self.HDVN_COOKIE,
            "user-agent": self.USER_AGENT
        }
        response = self.session.get(self.base_url, headers=headers, timeout=15)
        if response.status_code == 200:
            regex = r"\"_xfToken\" value=\"(.*)\""
            match = re.search(regex, response.text)
            return match.group(1)


class PhimNews:

    def __init__(self):
        self.USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36 Edg/115.0.0.0"
        self.USER_COOKIE = "xf_csrf=SkQa8L0wlINdSY7m; xf_user=19338%2CZ73eXJiROJaQvomlJbPLqKG1g3K1cUpbtCQEDVeM; xf_session=-yHNz7XT47zCkFLCIbwN9hYilEZ9kZyv"
        self.host = "phim.news"
        self.base_url = f"https://{self.host}"
        self.search_nodes = ['5', '29', '3', '28']
        self.session = Session()

    def search(self, title, **kwargs):
        try:
            year = kwargs.get('year')
            alias = kwargs.get('alias') or ''
            results = []
            cache_key = f"phimnews_{title}_{year}"
            cache_data = main_cache.get(cache_key)
            if cache_data:
                return cache_data
            headers = {
                "authority": self.host,
                "accept": "application/json, text/javascript, */*; q=0.01",
                "content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                "cookie": self.USER_COOKIE,
                "origin": self.base_url,
                "referer": f"{self.base_url}/search/",
                "user-agent": self.USER_AGENT,
                "x-ajax-referer": f"{self.base_url}/search/",
                "x-requested-with": "XMLHttpRequest",
            }
            _xf_token = self._get_xftoken()
            search_title = re.sub(r'^the', '', f'{title} {year}'.lower()).strip()
            if alias:
                search_title = ' '.join([title, alias])
            req_data = {
                'keywords': search_title if alias else f'"{search_title}"',
                'c[title_only]': '1',
                'c[users]': '',
                'c[child_nodes]': '1',
                'c[nodes][]': self.search_nodes,
                'order': 'date',
                # 'search_type': 'post',
                '_xfToken': _xf_token,
                '_xfRequestUri': '/search',
                '_xfWithData': '1',
                '_xfResponseType': 'json'
            }
            resp = self.session.post(self.base_url + '/search/search', headers=headers, data=req_data, timeout=15)
            resp.raise_for_status()
            resp_data = resp.json() if resp else {}
            if "redirect" in resp_data:
                results = self._get_list_items(resp_data.get("redirect"), headers, **dict(
                    title=title,
                    year=kwargs.get('year'),
                    season=kwargs.get('season'),
                    episode=kwargs.get('episode'),
                ))
                main_cache.set(cache_key, results, expiration=timedelta(days=30 if kwargs.get('season') else 1))
            return results
        except Exception as e:
            logger('PhimNews', f'Error: {e}')
            return []

    def _get_list_items(self, url, headers, **kwargs):
        title = kwargs.get('title')
        alias = kwargs.get('alias')
        year = kwargs.get('year')
        resp = self.session.get(url, headers=headers, timeout=15)
        link_results = []
        if resp.status_code == 200:
            soup = BeautifulSoup(resp.content, 'html.parser')
            block_result = soup.find("li", id="tab_defaultsearch")
            if not block_result:
                return []
            threads = block_result.find_all('li', class_="block-row")
            for thread in threads:
                h3 = thread.find('h3', class_='contentRow-title')
                name = re.sub(CLEAN_BRACKET_REGEX, '', h3.get_text()).strip()
                name = re.sub(CLEAN_REGEX, '', name).strip()
                href = f"{self.base_url}{h3.a.get('href')}"
                if len(threads) == 1 or title.lower() in name.lower() or \
                    (alias and alias.lower() in name.lower()):
                    link_results.append(href)

        results = []
        if link_results:
            for link in link_results[:3]:
                results.extend(self._get_link_content(link, headers))
        return results

    def _get_link_content(self, url, headers):
        def _get_links(soup):
            div = soup.find("div", class_="block--messages")
            if div:
                content = div.find("div", class_="message-userContent")
                links = content.find_all("a")
                try:
                    urls = [l.get('href') for l in links if 'fshare.vn' in l.get('href')]
                    if urls:
                        return urls[:1]
                except:
                    pass
            return []

        links = []
        resp = self.session.get(url, headers=headers, timeout=15)
        if resp.status_code == 200:
            soup = BeautifulSoup(resp.content, 'html.parser')
            links = _get_links(soup)
            if not links:
                _xf_token = soup.find("input", {"name": "_xfToken"}).get('value')
                attachment_hash = soup.find("input", {"name": "attachment_hash"}).get('value')
                attachment_hash_combined = soup.find("input", {"name": "attachment_hash_combined"}).get('value')
                last_date = soup.find("input", {"name": "last_date"}).get('value')
                last_known_date = soup.find("input", {"name": "last_known_date"}).get('value')
                self._add_reply(url, **dict(
                    _xfToken=_xf_token,
                    attachment_hash=attachment_hash,
                    attachment_hash_combined=attachment_hash_combined,
                    last_date=last_date,
                    last_known_date=last_known_date,
                ))
                response = self.session.get(url, headers=headers, timeout=15)
                if response.status_code == 200:
                    soup = BeautifulSoup(response.content, "html.parser")
                    links = _get_links(soup)
        return links

    def _add_reply(self, url, **kwargs):
        headers = {
            "authority": self.host,
            "accept": "application/json, text/javascript, */*; q=0.01",
            "content-type": "application/x-www-form-urlencoded; charset=UTF-8",
            "cookie": self.USER_COOKIE,
            "user-agent": self.USER_AGENT,
            "origin": self.base_url,
            "referer": url,
            "x-requested-with": "XMLHttpRequest"
        }
        req_data = kwargs
        req_data.update(
            message_html=f"<p>{random.choice(THANKS_CONTENT)}</p>",
            _xfWithData="1",
            _xfRequestUri=url,
            _xfResponseType="json",
        )
        self.session.post(f"{url}/add-reply", headers=headers, data=req_data, timeout=15)

    def _get_xftoken(self):
        headers = {
            "authority": self.host,
            "cookie": self.USER_COOKIE,
            "user-agent": self.USER_AGENT
        }
        response = self.session.get(self.base_url, headers=headers, timeout=15)
        if response.status_code == 200:
            regex = r"\"_xfToken\" value=\"(.*)\""
            match = re.search(regex, response.text)
            return match.group(1)


class TimFshare:
    base_url = 'https://timfshare.com'

    def __init__(self):
        self.session = Session()
        self.headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36',
            'Authorization': 'Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJuYW1lIjoiZnNoYXJlIiwidXVpZCI6IjcxZjU1NjFkMTUiLCJ0eXBlIjoicGFydG5lciIsImV4cGlyZXMiOjAsImV4cGlyZSI6MH0.WBWRKbFf7nJ7gDn1rOgENh1_doPc07MNsKwiKCJg40U',
        }

    def search(self, title, **kwargs):
        from fenom import source_utils

        year = kwargs.get('year')
        season = kwargs.get('season')
        episode = kwargs.get('episode')
        hdlr = 'S%02dE%02d' % (int(season), int(episode)) if season else year
        years = None
        if hdlr == year:
            years = [year]
            years.append(str(int(year) - 1))
        hdlr = 'S%02dE%02d' % (int(season), int(episode)) if season else year
        search_title = f'"{title}" {hdlr}'
        results = []
        resp = self.session.post(f'{self.base_url}/api/v1/string-query-search', params=dict(
                query=search_title,
            ), headers=self.headers, timeout=15)
        resp.raise_for_status()
        resp_data = resp.json() if resp else {}
        for item in resp_data.get('data', []):
            raw_name = item.get('name')
            if not re.match(VIDEO_REGEX, raw_name):
                continue
            raw_name = re.sub(CLEAN_BRACKET_REGEX, '', raw_name).strip()
            raw_name = re.sub(CLEAN_REGEX, '', raw_name).strip()
            name = source_utils.clean_name(raw_name)
            cleaned_title = source_utils.clean_name(title)
            if name.startswith(f"{year}."):
                name = name.lower().replace(f"{year}.{cleaned_title.lower()}", f"{cleaned_title}.{year}")
            if not source_utils.check_title(title, [], name, hdlr, year, years=years):
                continue
            id = item.get('id')
            link = f'https://www.fshare.vn/file/{id}'
            size = item.get('size')
            results.append({
                'title': name,
                'size': size,
                'link': link,
                'check': False
            })
        return results
