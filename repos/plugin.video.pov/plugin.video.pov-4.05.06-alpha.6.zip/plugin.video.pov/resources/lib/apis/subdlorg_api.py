import os
import re
from random import randint
from bs4 import BeautifulSoup
from io import BytesIO
from requests import Session
from datetime import timedelta
from caches.main_cache import main_cache
from modules.agent_lists import FIRST_THOUSAND_OR_SO_USER_AGENTS as AGENT_LIST
from modules.meta_lists import language_choices
from modules.kodi_utils import notification, sleep, delete_file, rename_file, logger
from modules.utils import slugify
from zipfile import ZipFile

BASE_URL = 'https://subdl.org'
timeout = 20
exts = [".idx", ".sup", ".srt", ".sub", ".str", ".ass"]

class SubdlOrgAPI:
    provider = 'subdl'

    def __init__(self):
        self.base_url = f"{BASE_URL}/{self.provider}"
        self.session = Session()
        self.headers = {
            'User-Agent': AGENT_LIST[randint(0, len(AGENT_LIST) - 1)],
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Accept-Language': 'en-US,en;q=0.5',
            'Accept-Encoding': 'gzip, deflate',
            'DNT': '1',
            'Connection': 'keep-alive',
            'Upgrade-Insecure-Requests': '1',
            'Cache-Control': 'max-age=0'
        }

    def _search_link(self, title, year):
        response = self._get(f"{self.base_url}/?srcname={title.lower().replace(' ', '+')}")
        if not response or response.status_code == 404:
            return None
        soup = BeautifulSoup(response.content, 'html.parser')
        tbl = soup.find('table')
        tbl_body = tbl.find('tbody') if tbl else None
        rows = tbl_body.findAll('tr') if tbl_body else []
        total_rows = len(rows)
        if total_rows == 1:
            return rows[0].find('a').get('href').rstrip('/')
        if year and total_rows > 1:
            for row in rows:
                link = row.find('a')
                result_title = link.text
                if year in result_title and title.lower() in result_title.lower():
                    return link.get('href').rstrip('/')

    def search(self, title, imdb_id, language, season=None, episode=1, **kwargs):
        search_year = kwargs.get('year')
        language_name = next(item[0] for item in language_choices.items() if item[1] == language)

        cache_name = 'subscene_subdl_%s_%s' % (language, imdb_id or title)
        if season:
            cache_name += f'_s{season}e{episode}'
        if search_year:
            cache_name += f'_{search_year}'
        cache = main_cache.get(cache_name)
        if cache:
            return cache

        search_name = slugify(title)
        item_url = f'{self.base_url}/list/{search_name}/{slugify(language_name)}'
        real_url = self._search_link(title, search_year)
        if real_url:
            item_url = real_url
        response = self._get(f'{item_url}/{slugify(language_name)}', retry=True)

        subtitles = []
        if not response or response.status_code == 404:
            return subtitles
        soup = BeautifulSoup(response.content, 'html.parser')
        tbl = soup.find('table', {'id': 'goodtable'})
        tbl_body = tbl.find('tbody') if tbl else None
        rows = tbl_body.findAll('tr') if tbl_body else []
        for row in rows:
            td = row.findAll('td')
            th = row.find('th')
            sub_lang = td[0].text.strip().lower()
            if sub_lang == language_name.lower():
                release_name = th.text[0:th.text.index(language_name.lower()):].strip()
                quality_match = re.search(r"[.](hd-ts|hdts|ts|cam)[.]", release_name, re.IGNORECASE)
                if quality_match and quality_match[0]:
                    continue
                try:
                    year = re.search(r"(?:[0-9]{4})", release_name)[0]
                except: year = None
                if search_year and year and year != search_year:
                    continue
                sub = dict(
                    name=release_name,
                    download_link=th.find('a').get('href').rstrip()
                )
                if season:
                    se = re.search(r"[Ss](\d{2})[Ee](\d{2})", release_name)
                    if se:
                        result_season = int(se.group(1))
                        result_episode = int(se.group(2))
                        if (result_season and season == result_season) and (result_episode and episode == result_episode):
                            self._add_sub(subtitles, language, sub)
                        else:
                            continue
                else:
                    self._add_sub(subtitles, language, sub)

        main_cache.set(cache_name, subtitles, expiration=timedelta(hours=24))
        return subtitles


    def download(self, url, filepath, temp_zip, temp_path, final_path):
        def _get_ext(f):
            for ext in exts:
                if os.path.splitext(f)[1] == ext:
                    return ext

        result = self._get(url)
        if 'text/html' in result.headers['content-type']:
            return
        s = BytesIO(result.content)
        with open(temp_zip, 'wb') as f:
            f.write(s.getvalue())
        extracted = False
        with ZipFile(temp_zip, 'r') as zip_file:
            list_files = zip_file.namelist()
            for file_ in list_files:
                ext = _get_ext(file_)
                if ext:
                    final_path = final_path.replace('.srt', ext)
                    zip_file.extract(file_, temp_path)
                    rename_file(os.path.join(temp_path, file_), final_path)
                    extracted = True
        delete_file(temp_zip)
        if extracted:
            return final_path

    def _add_sub(self, subtitles, language, sub):
        subtitles.append(dict(
            SubFileName=sub.get('name') + '.srt',
            SubLanguageID=language,
            MovieReleaseName=sub.get('name'),
            SubSumCD="1",
            SubFormat="srt",
            ZipDownloadLink=sub.get('download_link'),
        ))

    def _get(self, url, params=None, stream=False, retry=False, **kwargs):
        allow_redirects = kwargs.get('allow_redirects', False)
        get_headers = self.headers
        get_headers.update({'Referer': BASE_URL})
        if kwargs.get('referer'):
            get_headers.update({'Referer': kwargs.get('referer')})
        response = self.session.get(url, params=params, headers=get_headers, stream=stream, allow_redirects=allow_redirects, timeout=timeout)
        if response.status_code == 200: return response
        elif response.status_code == 429 and retry:
            notification(32740, 3000)
            sleep(10000)
            return self._get(url, params=params, stream=stream, retry=retry, **kwargs)
        else: return response


class SubsceneSubdlAPI(SubdlOrgAPI):
    provider = 'subscene'