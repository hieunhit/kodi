import re
from bs4 import BeautifulSoup
from requests import Session
from caches.main_cache import main_cache
from modules.kodi_utils import logger

class Anime47Api:
    base_url = 'https://anime47.blog'
    user_agent = 'Dalvik/2.1.0 (Linux; U; Android 13; Pixel 7 Pro Build/TQ1A.335336.002)'

    def __init__(self):
        self.session = Session()

    def search(self, title, **kwargs):
        cache_key = f"anime47_{title}_{kwargs.get('year')}_link"
        try:
            link = main_cache.get(cache_key)
            if not link:
                link = self._search_item(title, **kwargs)
                if not link:
                    return
                main_cache.set(cache_key, link)
            episode_id = self._search_episode(link, **kwargs)
            if episode_id:
                play_url = self._get_play_link(episode_id)
                if play_url:
                    return {
                        'title': f"{title} {kwargs.get('year')} 1080p Webdl Anime47",
                        "link": play_url,
                        "check": False,
                    }
        except:
            return

    def _search_item(self, title, **kwargs):
        title_alias = kwargs.get('alias')
        has_alias = title_alias is not None
        url_search = f"{self.base_url}/tim-nang-cao/?keyword={title.replace(' ', '+')}&nam=&season=&status=&sapxep=1"
        if title_alias:
            url_search = f"{self.base_url}/tim-nang-cao/?keyword={title_alias.replace(' ', '+')}&nam=&season=&status=&sapxep=1"
        headers = {
            'User-Agent': self.user_agent,
            'Referer': self.base_url
        }
        result = []
        resp = self.session.get(url_search, headers=headers)
        resp.raise_for_status()
        soup = BeautifulSoup(resp.content, 'html.parser')
        items = soup.select('ul.last-film-box a')
        if not items and has_alias:
            resp = self.session.get(f"{self.base_url}/tim-nang-cao/?keyword={title.replace(' ', '+')}&nam=&season=&status=&sapxep=1", headers=headers)
            resp.raise_for_status()
            soup = BeautifulSoup(resp.content, 'html.parser')
            items = soup.select('ul.last-film-box a')
        for k in items:
            item_name = k['title']
            item_name_lower = item_name.lower()
            url = re.sub(r'^\./', self.base_url + '/', k['href'])
            if title.lower() in item_name_lower or title_alias.lower() in item_name_lower:
                result.append(url)

        if result:
            return self._get_item_link(result[0])

    def _get_item_link(self, url):
        resp = self.session.get(url, headers={
            'User-Agent': self.user_agent,
        })
        link = None
        if resp.status_code == 200:
            soup = BeautifulSoup(resp.content, 'html.parser')
            watch_btn = soup.find('a', id='btn-film-watch')
            if watch_btn:
                link = re.sub(r'^\./', self.base_url + '/', watch_btn['href'])
        return link

    def _search_episode(self, url, **kwargs):
        season = kwargs.get('season')
        episode = kwargs.get('episode')
        resp = self.session.get(url, headers={
            'User-Agent': self.user_agent,
        })
        result_id = None
        if resp.status_code == 200:
            soup = BeautifulSoup(resp.content, 'html.parser')
            for s in soup.select('div.server div.name'):
                s_title = s.get_text().strip()
                if s_title.lower() == 'tổng hợp' or s_title.lower() == f'phần {season}':
                    ep_div = s.find_next_sibling('div', class_="episodes")
                    for a in ep_div.find_all('a'):
                        if a.get('data-episode-name') == episode.zfill(len(a.get('data-episode-name'))):
                            result_id = a.get('data-episode-id')
                            break
        return result_id

    def _get_play_link(self, episode_id):
        req_url = f'{self.base_url}/player/player.php'
        req_data = {
            'ID': episode_id,
            'SV': '4',
            'SV4': '4',
        }
        resp = self.session.post(req_url, data=req_data, headers={
            'User-Agent': self.user_agent,
            'X-Requested-With': 'XMLHttpRequest'
        })
        if resp.status_code == 200:
            play_link = re.search(r'"file".*?"(.*?)"', resp.text)[1]
            play_link = re.sub(r'\s+', '%20', play_link.strip(), flags=re.UNICODE)
            return play_link