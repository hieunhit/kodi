import re
from apis.fshare_api import FshareAPI
from fenom import source_utils
from modules.kodi_utils import logger

class source:
    priority = 1
    pack_capable = False
    hasMovies = True
    hasEpisodes = True

    def __init__(self):
        self.language = ['en', 'vi']
        self.fshare_api = FshareAPI()

    def sources(self, data, hostDict):
        sources = []
        if not data:
            return sources
        append = sources.append
        try:
            title = data['tvshowtitle'] if 'tvshowtitle' in data else data['title']
            episode_title = data['title'] if 'tvshowtitle' in data else None
            aliases = data.get('aliases') or []
            aliases_list = [a['title'] for a in aliases]
            year = data.get('year')
            season = data.get('season')
            episode = data.get('episode')
            genres = data.get('genres', [])
            hdlr = 'S%02dE%02d' % (int(season), int(episode)) if 'tvshowtitle' in data else year
            if episode_title:
                for genre in genres:
                    if genre.lower() in ['anime', 'phim hoạt hình']:
                        self.fshare_api.set_search_anime(True)
                        break
            results = self.fshare_api.search(title, year=year, season=season, episode=episode, alias=aliases_list[0] if aliases_list else None)
            logger('FSHARE', f'[Scrape] {title}: {len(results)}')

            for item in results:
                url = item.get('link')
                raw_name = item['title'].lower()
                name_parts = raw_name.split('-', 1)
                if len(name_parts) == 2:
                    for i, n in enumerate(name_parts):
                        if title.lower() in n:
                            pos = i + 1 if i == 0 else i - 1
                            raw_name = raw_name.replace(name_parts[pos], '').strip()
                            break
                for alias in aliases_list:
                    if alias.lower() in raw_name:
                        raw_name = raw_name.replace(alias.lower(), title)
                        break
                if season and int(season) == 1:
                    raw_name = re.sub(r'\.e[\s|p]?(\d{1,3})\.', r'.S%02dE\1.' % 1, raw_name)
                raw_name = raw_name.replace('-', ' ').replace('_', ' ')
                name = source_utils.clean_name(raw_name)
                if item.get('check') is None and not source_utils.check_title(title, aliases, name, hdlr, year):
                    continue
                name_info = source_utils.info_from_name(name, title, year, hdlr, episode_title)
                quality, info = source_utils.get_release_quality(name_info, url)
                try:
                    dsize, isize = source_utils.convert_size(float(item["size"]), to='GB')
                    info.insert(0, isize)
                except:
                    dsize = 0
                info = ' | '.join(info)

                is_exists = any(s for s in sources if s['quality'] == quality and s['size'] == dsize)
                if not is_exists:
                    append({'provider': 'fshare', 'source': 'hoster', 'name': name, 'name_info': name_info,
                            'quality': quality, 'language': 'vi', 'url': url, 'info': info,
                            'direct': True, 'debridonly': False, 'size': dsize})
            # if len(sources) == 0 and len(results) > 0:
            #     logger('FSHARE', f'[Scrape filter]: {results}')
            logger('FSHARE', f'[Scrape filter] {title}: {len(sources)} results')
        except:
            source_utils.scraper_error('FSHARE')
        return sources
