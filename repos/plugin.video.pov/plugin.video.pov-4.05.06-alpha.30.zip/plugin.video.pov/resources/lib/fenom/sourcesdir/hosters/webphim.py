import requests
import re
from datetime import datetime
from requests.adapters import HTTPAdapter, Retry
from fenom import source_utils
from threading import Thread
from apis.anime_api import Anime47Api, AnimeHayApi, HH3DApi
from modules.kodi_utils import logger


def requests_retry_session(
    retries=3,
    backoff_factor=0.3,
    status_forcelist=(429, 500, 502, 503, 504),
    session=None,
):
    session = session or requests.Session()
    retry = Retry(
        total=retries,
        read=retries,
        connect=retries,
        backoff_factor=backoff_factor,
        status_forcelist=status_forcelist,
    )
    adapter = HTTPAdapter(max_retries=retry)
    session.mount('http://', adapter)
    session.mount('https://', adapter)
    return session


class OPhim:
    base_url = 'https://ophim1.com'
    user_agent = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36 Edg/115.0.0.0'

    def __init__(self):
        self.session = requests.Session()
        self.headers = {
            'Accept': '*/*',
            'User-Agent': self.user_agent,
        }

    def search(self, title, **kwargs):
        try:
            alias = kwargs.get('alias') or ''
            year = int(kwargs.get('year'))
            season = kwargs.get('season')
            hdlr = 'S%02dE%02d' % (int(kwargs.get('season')), int(kwargs.get('episode'))) if kwargs.get('season') else year
            search_title = title
            resp_data = requests_retry_session(self.session).get(f'{self.base_url}/v1/api/tim-kiem', params={
                'keyword': search_title
            }, headers=self.headers, timeout=15)
            resp_data.raise_for_status()
            data = resp_data.json().get('data', {}) if resp_data else None
            if data is None:
                return
            items = data.get('items', [])
            if not items:
                return
            slug = None
            link = None
            season_names = None
            season_year = None
            if season:
                cur_s = [s for s in kwargs.get('season_data', []) if s.get('season_number') == int(season)]
                if cur_s:
                    release_date = cur_s[0].get('air_date')
                    season_year = int(datetime.strptime(release_date, '%Y-%m-%d').year) if release_date else year
                if int(season) > 1:
                    season_names = [f"{title.lower()} {season}", f"{title.lower()} (season {season})"]
                    if alias:
                        season_names.append(f"{alias.lower()} {season}")
            for i in items:
                name = re.sub(r'\s?\(.+?\)', '', i.get('name').split(' - ')[0]).strip()
                orig_name = re.sub(r'\s?\(.+?\)', '', i.get('origin_name')).strip()
                names = [name.lower(), orig_name.lower()]
                if season_names:
                    if name.lower() in season_names or orig_name.lower() in season_names:
                        slug = i.get('slug')
                        break
                    elif (title.lower() in names or alias.lower() in names) and i.get('year') == season_year:
                        slug = i.get('slug')
                        break
                elif not season_names and (title.lower() in names or alias.lower() in names):
                    slug = i.get('slug')
                    break
            if slug:
                link = self._get_link(slug, **kwargs)
            if link:
                return {
                    'title': f'{title} {hdlr} 1080p webdl',
                    'link': f'hls|{link}',
                    'provider': 'ophim',
                }
        except Exception as e:
            logger('OPhim', f'Error: {e}')
        
    def _get_link(self, slug, **kwargs):
        episode = kwargs.get('episode')
        resp_data = requests_retry_session(self.session).get(f'{self.base_url}/phim/{slug}', headers=self.headers, timeout=15)
        resp_data.raise_for_status()
        data = resp_data.json() if resp_data else None
        if data is None:
            return
        try:
            _ep = None
            episodes = data.get('episodes', [])[0].get('server_data', [])
            if not episode:
                _ep = episodes[0]
            else:
                for ep in episodes:
                    e_no = ep.get('name')
                    e_range = []
                    if '-' in e_no:
                        e_range = e_no.split('-', 1)
                    if e_no == episode or (e_range and int(episode) in range(int(e_range[0]), int(e_range[1]))):
                        _ep = ep
                        break
            if _ep:
                return _ep.get('link_m3u8')
        except: pass

class source:
    priority = 5
    pack_capable = False
    hasMovies = True
    hasEpisodes = True

    def __init__(self):
        self.language = ['en', 'vi']
        self.ophim_api = OPhim()
        self.anime47 = Anime47Api()
        self.animehay = AnimeHayApi()
        self.hh3d = HH3DApi()

    def sources(self, data, hostDict):
        sources = []
        if not data:
            return sources
        append = sources.append
        try:
            title = data['tvshowtitle'] if 'tvshowtitle' in data else data['title']
            episode_title = data['title'] if 'tvshowtitle' in data else None
            aliases = data.get('aliases') or []
            aliases_list = [a['title'] for a in aliases]
            alias = aliases_list[0] if aliases_list else None
            year = data.get('year')
            season = data.get('season')
            episode = data.get('episode')
            genres = data.get('genres', [])
            season_data = data.get('season_data', [])
            hdlr = 'S%02dE%02d' % (int(season), int(episode)) if 'tvshowtitle' in data else year
            flatten_episode = 0
            for s in sorted(season_data, key=lambda d: d['season_number']):
                season_number = s.get('season_number')
                episode_count = s.get('episode_count')
                if season_number == 0:
                    continue
                if season_number < int(season):
                    flatten_episode += episode_count
                elif season_number == int(season):
                    flatten_episode += int(episode)
                    break
            search_extra = dict(
                year=year,
                season=season,
                episode=episode,
                flatten_episode=flatten_episode if flatten_episode > 0 else None,
                season_data=season_data,
                alias=alias,
            )

            results = []
            threads = []
            threads.append(Thread(target=self._search_ophim, args=(title, results), kwargs=search_extra))
            for genre in genres:
                if genre.lower() in ['anime', 'phim hoạt hình']:
                    threads.append(Thread(target=self._search_anime47, args=(title, results), kwargs=search_extra))
                    threads.append(Thread(target=self._search_animehay, args=(title, results), kwargs=search_extra))
                    threads.append(Thread(target=self._search_hh3d, args=(title, results), kwargs=search_extra))
                    break
            for t in threads:
                t.start()
            for t in threads:
                t.join()

            logger('WEBPHIM', f'[Scrape] {title}: {len(results)}')
            for item in results:
                url = item.get('link')
                raw_name = item['title'].lower()
                name = source_utils.clean_name(raw_name)
                name_info = source_utils.info_from_name(name, title, year, hdlr, episode_title)
                quality, info = source_utils.get_release_quality(name_info, url)
                try:
                    dsize, isize = source_utils.convert_size(float(item["size"]), to='GB')
                    info.insert(0, isize)
                except:
                    dsize = 0
                info = ' | '.join(info)

                append({'provider': 'webphim', 'source': item.get('provider', 'hoster'), 'name': name, 'name_info': name_info,
                        'quality': quality, 'language': 'vi', 'url': url, 'info': info,
                        'direct': True, 'debridonly': False, 'size': dsize})
        except Exception as e:
            logger('WEBPHIM', f"Error: {e}")
            source_utils.scraper_error('WEBPHIM')
        return sources

    def _search_ophim(self, title, result, **kwargs):
        link = self.ophim_api.search(title, **kwargs)
        if link:
            result.extend([link])
        return [link]
    
    def _search_anime47(self, title, result, **kwargs):
        link = self.anime47.search(title, **kwargs)
        if link:
            result.extend([link])
        return [link]

    def _search_animehay(self, title, result, **kwargs):
        link = self.animehay.search(title, **kwargs)
        if link:
            result.extend([link])
        return [link]

    def _search_hh3d(self, title, result, **kwargs):
        link = self.hh3d.search(title, **kwargs)
        if link:
            result.extend([link])
        return [link]
