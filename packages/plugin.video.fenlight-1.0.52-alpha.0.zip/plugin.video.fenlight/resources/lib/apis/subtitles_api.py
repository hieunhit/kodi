# -*- coding: utf-8 -*-
import xmlrpc


OS_BASE_URL_XMLRPC = "http://api.opensubtitles.org/xml-rpc"
SUBSCENE_BASE_URL = "https://subscene.com"


class OpenSubtitlesAPI:

    def __init__(self):
        self.server = xmlrpc.client.ServerProxy(OS_BASE_URL_XMLRPC, verbose=0)

        login = self.server.LogIn("", "", "en", "%s_v%s" %("XBMC_Subtitles_Unofficial", "5.5.3"))
        self.osdb_token = login[ "token" ]

    def search_subtitle(self, meta, language):
        pass

class SubsceneAPI:

    def search_subtitle(self, meta, language):
        pass


def search(meta, language):
    meta['subtitle'] = 'Vietnamese'
