import os
import json
import shutil
import random
import requests
import xbmc
import xbmcvfs
from datetime import timedelta
from caches.main_cache import main_cache
from modules.kodi_utils import notification, sleep, delete_file, rename_file
from zipfile import ZipFile

SUBDL_API_SEARCH_URL = "https://api.subdl.com/api/v1/subtitles"
SUBDL_API_DOWNLOAD_URL = "https://dl.subdl.com"
timeout = 20

exts = [".idx", ".sup", ".srt", ".sub", ".str", ".ass"]

class SubdlAPI:

    def __init__(self) -> None:
        self.cache_api_keys = 'subdl_keys'
        self.headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36'}

    def search(self, query, imdb_id, language, season=None, episode=None, **kwargs):
        tmdb_id = kwargs.get("tmdb_id")
        year = kwargs.get("year")
        cache_name = 'subdl_%s_%s' % (imdb_id or tmdb_id, language)
        if season: cache_name += '_%s_%s' % (season, episode)
        cache = main_cache.get(cache_name)
        if cache: return cache
        _ , api_key_value = self._get_random_api_key()
        media_type = 'movie' if not season else 'tv'
        search_language = xbmc.convertLanguage(language, xbmc.ISO_639_1) if len(language) > 2 else language
        querystring = {
            'api_key': api_key_value,
            'subs_per_page': 30,
            'languages': search_language,
            'type': media_type,
        }
        if imdb_id:
            if imdb_id.startswith('tt'):
                querystring['imdb_id'] = imdb_id
            else:
                querystring['imdb_id'] = f"tt{imdb_id}"
        if tmdb_id:
            querystring['tmdb_id'] = tmdb_id
        if not imdb_id and not tmdb_id and query:
            querystring['film_name'] = query
        if year:
            querystring['year'] = year
        if media_type == 'tv':
            querystring['season_number'] = season
            querystring['episode_number'] = episode

        response = self._get(SUBDL_API_SEARCH_URL, params=querystring, retry=True)
        response = json.loads(response.text) if response else {}
        resp_subtitles = response.get('subtitles', []) if 'subtitles' in response else []

        # parse response to match opensubtitles response
        subtitles = []
        for sub in resp_subtitles:
            subtitle = dict()
            subtitle['SubFileName'] = sub['name'].replace('SUBDL::', '')
            subtitle['SubLanguageID'] = language
            subtitle['MovieReleaseName'] = sub['release_name']
            subtitle['SubSumCD'] = '1'
            subtitle['SubFormat'] = 'srt'
            subtitle['ZipDownloadLink'] = f"{SUBDL_API_DOWNLOAD_URL}{sub['url']}"
            subtitles.append(subtitle)

        main_cache.set(cache_name, subtitles, expiration=timedelta(hours=24))
        return subtitles

    def download(self, url, filepath, temp_zip, temp_path, final_path):
        result = self._get(url, stream=True, retry=True)
        with open(temp_zip, 'wb') as f: shutil.copyfileobj(result.raw, f)
        with ZipFile(temp_zip, 'r') as zip_file: zip_file.extractall(filepath)
        delete_file(temp_zip)
        for file_ in xbmcvfs.listdir(filepath)[1]:
            ufile = file_
            file_ = os.path.join(filepath, ufile)
            for ext in exts:
                if os.path.splitext(ufile)[1] == ext:
                    final_path.replace('.srt', ext)
                    rename_file(file_, final_path)
        return final_path

    def _get(self, url, params=None, stream=False, retry=False):
        response = requests.get(url, params, headers=self.headers, stream=stream, timeout=timeout)
        if response.status_code == 200: return response
        elif response.status_code == 429 and retry:
            notification(32740, 3000)
            sleep(10000)
            _, api_key = self._get_random_api_key()
            params['api_key'] = api_key
            return self._get(url, params=params, stream=stream)
        else: return

    def _get_api_keys(self):
        response = self._get('https://kodi7rd.github.io/repository/other/DarkSubs_SubDL/temp_darksubs_subdl_api.json')
        response = json.loads(response.text)
        response.insert(0, {
            'SUBDL_API_KEY_NAME': 'my_api_key',
            'SUBDL_API_KEY_VALUE': 'gYdilxbnVMI2Q6O6f24RpsoRpDjSPvTh'
        })
        main_cache.set(self.cache_api_keys, response, expiration=timedelta(hours=24))
        return response

    def _get_random_api_key(self):
        cache = main_cache.get(self.cache_api_keys)
        if not cache:
            cache = self._get_api_keys()

        random_key_index = random.randint(0, len(cache) - 1)
        return cache[random_key_index]['SUBDL_API_KEY_NAME'], cache[random_key_index]['SUBDL_API_KEY_VALUE']
